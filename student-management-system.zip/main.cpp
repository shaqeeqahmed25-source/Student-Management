#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <limits>

using namespace std;

// Student Class Definition
class Student {
private:
    char rollNumber[20];
    char name[50];
    int age;
    char gender[15];
    char department[50];
    char year[15];
    char phone[20];
    char email[50];
    char address[100];
    double cgpa;

public:
    // Default Constructor
    Student() {
        strcpy(rollNumber, "");
        strcpy(name, "");
        age = 0;
        strcpy(gender, "");
        strcpy(department, "");
        strcpy(year, "");
        strcpy(phone, "");
        strcpy(email, "");
        strcpy(address, "");
        cgpa = 0.0;
    }

    // Parameterized Constructor
    Student(const char* r, const char* n, int a, const char* g, const char* dept, 
            const char* y, const char* p, const char* e, const char* addr, double c) {
        strncpy(rollNumber, r, 19); rollNumber[19] = '\0';
        strncpy(name, n, 49); name[49] = '\0';
        age = a;
        strncpy(gender, g, 14); gender[14] = '\0';
        strncpy(department, dept, 49); department[49] = '\0';
        strncpy(year, y, 14); year[14] = '\0';
        strncpy(phone, p, 19); phone[19] = '\0';
        strncpy(email, e, 49); email[49] = '\0';
        strncpy(address, addr, 99); address[99] = '\0';
        cgpa = c;
    }

    // Getters
    const char* getRollNumber() const { return rollNumber; }
    const char* getName() const { return name; }
    int getAge() const { return age; }
    const char* getGender() const { return gender; }
    const char* getDepartment() const { return department; }
    const char* getYear() const { return year; }
    const char* getPhone() const { return phone; }
    const char* getEmail() const { return email; }
    const char* getAddress() const { return address; }
    double getCGPA() const { return cgpa; }

    // Setters
    void setRollNumber(const char* r) { strncpy(rollNumber, r, 19); rollNumber[19] = '\0'; }
    void setName(const char* n) { strncpy(name, n, 49); name[49] = '\0'; }
    void setAge(int a) { age = a; }
    void setGender(const char* g) { strncpy(gender, g, 14); gender[14] = '\0'; }
    void setDepartment(const char* dept) { strncpy(department, dept, 49); department[49] = '\0'; }
    void setYear(const char* y) { strncpy(year, y, 14); year[14] = '\0'; }
    void setPhone(const char* p) { strncpy(phone, p, 19); phone[19] = '\0'; }
    void setEmail(const char* e) { strncpy(email, e, 49); email[49] = '\0'; }
    void setAddress(const char* addr) { strncpy(address, addr, 99); address[99] = '\0'; }
    void setCGPA(double c) { cgpa = c; }

    // Method to display student record in detail view
    void displayDetail() const {
        cout << "\n=========================================\n";
        cout << "            STUDENT RECORD DETAIL        \n";
        cout << "=========================================\n";
        cout << left << setw(18) << "Roll Number:" << rollNumber << "\n";
        cout << left << setw(18) << "Name:" << name << "\n";
        cout << left << setw(18) << "Age:" << age << " Years\n";
        cout << left << setw(18) << "Gender:" << gender << "\n";
        cout << left << setw(18) << "Department:" << department << "\n";
        cout << left << setw(18) << "Academic Year:" << year << "\n";
        cout << left << setw(18) << "Phone Number:" << phone << "\n";
        cout << left << setw(18) << "Email Address:" << email << "\n";
        cout << left << setw(18) << "Home Address:" << address << "\n";
        cout << left << setw(18) << "CGPA:" << fixed << setprecision(2) << cgpa << " / 4.00\n";
        cout << "=========================================\n";
    }

    // Method to display student record in brief tabular row format
    void displayRow() const {
        cout << "| " << left << setw(12) << rollNumber 
             << "| " << left << setw(18) << name 
             << "| " << right << setw(3) << age 
             << " | " << left << setw(7) << gender 
             << "| " << left << setw(15) << department 
             << "| " << left << setw(8) << year 
             << "| " << right << setw(5) << fixed << setprecision(2) << cgpa << " |\n";
    }
};

// Function Prototypes
void addStudent();
void displayStudents();
void searchStudent();
void updateStudent();
void deleteStudent();
void menu();
bool isRollNumberUnique(const char* rollNum);
void cleanInputBuffer();
bool validatePhone(const char* ph);
bool validateEmail(const char* em);

// Constants
const char* FILE_NAME = "students.dat";

int main() {
    menu();
    return 0;
}

// Helper: Clear standard input buffer
void cleanInputBuffer() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

// Helper: Check if roll number already exists in binary file
bool isRollNumberUnique(const char* rollNum) {
    ifstream infile(FILE_NAME, ios::binary);
    if (!infile) {
        return true; // File doesn't exist, so Roll Number is unique
    }
    
    Student temp;
    while (infile.read(reinterpret_cast<char*>(&temp), sizeof(Student))) {
        if (strcmp(temp.getRollNumber(), rollNum) == 0) {
            infile.close();
            return false; // Found match, not unique
        }
    }
    infile.close();
    return true;
}

// Helper: Simple validate for email
bool validateEmail(const char* em) {
    string emailStr(em);
    size_t atPos = emailStr.find('@');
    size_t dotPos = emailStr.find('.', atPos);
    return (atPos != string::npos && dotPos != string::npos && dotPos > atPos + 1);
}

// Helper: Simple validate for phone (numbers only, standard size)
bool validatePhone(const char* ph) {
    if (strlen(ph) < 5) return false;
    for (size_t i = 0; i < strlen(ph); ++i) {
        if (!isdigit(ph[i]) && ph[i] != '+' && ph[i] != '-' && ph[i] != ' ') {
            return false;
        }
    }
    return true;
}

// Feature 1: Add a New Student Record
void addStudent() {
    cout << "\n=========================================\n";
    cout << "           ADD NEW STUDENT RECORD        \n";
    cout << "=========================================\n";

    char rollNum[20];
    char name[50];
    int age;
    char gender[15];
    char dept[50];
    char year[15];
    char phone[20];
    char email[50];
    char addr[100];
    double cgpa;

    // Roll Number Input with uniqueness validation
    while (true) {
        cout << "Enter Roll Number (Unique): ";
        cin.getline(rollNum, 20);
        if (strlen(rollNum) == 0) {
            cout << "Error: Roll Number cannot be empty!\n";
            continue;
        }
        if (!isRollNumberUnique(rollNum)) {
            cout << "Error: Student with Roll Number '" << rollNum << "' already exists!\n";
            continue;
        }
        break;
    }

    // Name Input
    while (true) {
        cout << "Enter Name: ";
        cin.getline(name, 50);
        if (strlen(name) == 0) {
            cout << "Error: Name cannot be empty!\n";
            continue;
        }
        break;
    }

    // Age Input
    while (true) {
        cout << "Enter Age: ";
        cin >> age;
        if (cin.fail() || age <= 0 || age > 120) {
            cout << "Error: Please enter a valid age (1-120).\n";
            cleanInputBuffer();
            continue;
        }
        cleanInputBuffer();
        break;
    }

    // Gender Input
    while (true) {
        cout << "Enter Gender (Male/Female/Other): ";
        cin.getline(gender, 15);
        if (strlen(gender) == 0) {
            cout << "Error: Gender cannot be empty!\n";
            continue;
        }
        break;
    }

    // Department Input
    while (true) {
        cout << "Enter Department (e.g. Computer Science): ";
        cin.getline(dept, 50);
        if (strlen(dept) == 0) {
            cout << "Error: Department cannot be empty!\n";
            continue;
        }
        break;
    }

    // Year Input
    while (true) {
        cout << "Enter Year (e.g., 1st Year, Sophomore): ";
        cin.getline(year, 15);
        if (strlen(year) == 0) {
            cout << "Error: Academic Year cannot be empty!\n";
            continue;
        }
        break;
    }

    // Phone Input
    while (true) {
        cout << "Enter Phone Number: ";
        cin.getline(phone, 20);
        if (!validatePhone(phone)) {
            cout << "Error: Invalid phone format. Use digits, space, '+' or '-'.\n";
            continue;
        }
        break;
    }

    // Email Input
    while (true) {
        cout << "Enter Email: ";
        cin.getline(email, 50);
        if (!validateEmail(email)) {
            cout << "Error: Invalid email format (example: name@domain.com).\n";
            continue;
        }
        break;
    }

    // Address Input
    while (true) {
        cout << "Enter Address: ";
        cin.getline(addr, 100);
        if (strlen(addr) == 0) {
            cout << "Error: Address cannot be empty!\n";
            continue;
        }
        break;
    }

    // CGPA Input
    while (true) {
        cout << "Enter CGPA (0.00 - 4.00): ";
        cin >> cgpa;
        if (cin.fail() || cgpa < 0.0 || cgpa > 4.0) {
            cout << "Error: Please enter a valid CGPA between 0.00 and 4.00.\n";
            cleanInputBuffer();
            continue;
        }
        cleanInputBuffer();
        break;
    }

    // Construct Student Object
    Student newStudent(rollNum, name, age, gender, dept, year, phone, email, addr, cgpa);

    // Save record to file
    ofstream outfile(FILE_NAME, ios::binary | ios::app);
    if (!outfile) {
        cout << "\nError: Critical system error! Unable to open data file for writing.\n";
        return;
    }

    outfile.write(reinterpret_cast<char*>(&newStudent), sizeof(Student));
    outfile.close();

    cout << "\nSuccess: Student record added successfully!\n";
}

// Feature 2: Display All Student Records
void displayStudents() {
    ifstream infile(FILE_NAME, ios::binary);
    if (!infile) {
        cout << "\n========================================================================================\n";
        cout << "No student records found. The database file is currently empty or has not been created.\n";
        cout << "========================================================================================\n";
        return;
    }

    Student s;
    bool recordsFound = false;

    // Header structure
    cout << "\n" << string(80, '=') << "\n";
    cout << "                             LIST OF ALL STUDENTS RECORDS                               \n";
    cout << string(80, '=') << "\n";
    cout << "| " << left << setw(12) << "Roll Number" 
         << "| " << left << setw(18) << "Name" 
         << "| " << left << setw(3) << "Age" 
         << " | " << left << setw(7) << "Gender" 
         << "| " << left << setw(15) << "Department" 
         << "| " << left << setw(8) << "Year" 
         << "| " << left << setw(5) << "CGPA" << " |\n";
    cout << string(80, '-') << "\n";

    while (infile.read(reinterpret_cast<char*>(&s), sizeof(Student))) {
        s.displayRow();
        recordsFound = true;
    }
    infile.close();

    if (!recordsFound) {
        cout << "| No records available in the file.                                                    |\n";
    }
    cout << string(80, '=') << "\n";
}

// Feature 3: Search Student by Roll Number
void searchStudent() {
    cout << "\n=========================================\n";
    cout << "         SEARCH STUDENT RECORD           \n";
    cout << "=========================================\n";

    ifstream infile(FILE_NAME, ios::binary);
    if (!infile) {
        cout << "Error: No student records exist yet. Database file is empty.\n";
        return;
    }

    char searchRoll[20];
    cout << "Enter Roll Number to search: ";
    cin.getline(searchRoll, 20);

    Student s;
    bool found = false;

    while (infile.read(reinterpret_cast<char*>(&s), sizeof(Student))) {
        if (strcmp(s.getRollNumber(), searchRoll) == 0) {
            s.displayDetail();
            found = true;
            break;
        }
    }
    infile.close();

    if (!found) {
        cout << "\nError: Student with Roll Number '" << searchRoll << "' not found.\n";
    }
}

// Feature 4: Update Student Details
void updateStudent() {
    cout << "\n=========================================\n";
    cout << "         UPDATE STUDENT DETAILS          \n";
    cout << "=========================================\n";

    fstream file(FILE_NAME, ios::binary | ios::in | ios::out);
    if (!file) {
        cout << "Error: No records found to update. File does not exist.\n";
        return;
    }

    char updateRoll[20];
    cout << "Enter the Roll Number of the student to update: ";
    cin.getline(updateRoll, 20);

    Student s;
    bool found = false;
    streampos pos;

    while (true) {
        pos = file.tellg(); // Track current position of read pointer
        if (!file.read(reinterpret_cast<char*>(&s), sizeof(Student))) {
            break;
        }

        if (strcmp(s.getRollNumber(), updateRoll) == 0) {
            found = true;
            cout << "\n--- Current Record Details ---";
            s.displayDetail();

            cout << "\nEnter New Details (Leave empty/enter 0 to retain current value):\n\n";

            char name[50], gender[15], dept[50], year[15], phone[20], email[50], addr[100];
            string input;

            // Update Name
            cout << "Enter New Name [" << s.getName() << "]: ";
            cin.getline(name, 50);
            if (strlen(name) > 0) s.setName(name);

            // Update Age
            while (true) {
                cout << "Enter New Age [" << s.getAge() << "]: ";
                getline(cin, input);
                if (input.empty()) {
                    break; // Keep existing
                }
                try {
                    int newAge = stoi(input);
                    if (newAge > 0 && newAge <= 120) {
                        s.setAge(newAge);
                        break;
                    } else {
                        cout << "Error: Age must be between 1 and 120.\n";
                    }
                } catch (...) {
                    cout << "Error: Please enter a valid number.\n";
                }
            }

            // Update Gender
            cout << "Enter New Gender [" << s.getGender() << "]: ";
            cin.getline(gender, 15);
            if (strlen(gender) > 0) s.setGender(gender);

            // Update Department
            cout << "Enter New Department [" << s.getDepartment() << "]: ";
            cin.getline(dept, 50);
            if (strlen(dept) > 0) s.setDepartment(dept);

            // Update Year
            cout << "Enter New Academic Year [" << s.getYear() << "]: ";
            cin.getline(year, 15);
            if (strlen(year) > 0) s.setYear(year);

            // Update Phone
            while (true) {
                cout << "Enter New Phone Number [" << s.getPhone() << "]: ";
                cin.getline(phone, 20);
                if (strlen(phone) == 0) {
                    break; // Keep existing
                }
                if (validatePhone(phone)) {
                    s.setPhone(phone);
                    break;
                }
                cout << "Error: Invalid phone format. Try again.\n";
            }

            // Update Email
            while (true) {
                cout << "Enter New Email [" << s.getEmail() << "]: ";
                cin.getline(email, 50);
                if (strlen(email) == 0) {
                    break; // Keep existing
                }
                if (validateEmail(email)) {
                    s.setEmail(email);
                    break;
                }
                cout << "Error: Invalid email format. Try again.\n";
            }

            // Update Address
            cout << "Enter New Address [" << s.getAddress() << "]: ";
            cin.getline(addr, 100);
            if (strlen(addr) > 0) s.setAddress(addr);

            // Update CGPA
            while (true) {
                cout << "Enter New CGPA [" << s.getCGPA() << "]: ";
                getline(cin, input);
                if (input.empty()) {
                    break; // Keep existing
                }
                try {
                    double newCGPA = stod(input);
                    if (newCGPA >= 0.0 && newCGPA <= 4.0) {
                        s.setCGPA(newCGPA);
                        break;
                    } else {
                        cout << "Error: CGPA must be between 0.00 and 4.00.\n";
                    }
                } catch (...) {
                    cout << "Error: Please enter a valid decimal number.\n";
                }
            }

            // Write modified object back to same location
            file.seekp(pos); // Move write pointer to start of this record
            file.write(reinterpret_cast<char*>(&s), sizeof(Student));
            cout << "\nSuccess: Student record updated successfully!\n";
            break;
        }
    }
    file.close();

    if (!found) {
        cout << "\nError: Student with Roll Number '" << updateRoll << "' not found.\n";
    }
}

// Feature 5: Delete Student Record Safely using Temporary File
void deleteStudent() {
    cout << "\n=========================================\n";
    cout << "         DELETE STUDENT RECORD           \n";
    cout << "=========================================\n";

    ifstream infile(FILE_NAME, ios::binary);
    if (!infile) {
        cout << "Error: No records found to delete. File does not exist.\n";
        return;
    }

    char deleteRoll[20];
    cout << "Enter the Roll Number of the student to delete: ";
    cin.getline(deleteRoll, 20);

    // Scan if student exists first
    Student s;
    bool found = false;
    while (infile.read(reinterpret_cast<char*>(&s), sizeof(Student))) {
        if (strcmp(s.getRollNumber(), deleteRoll) == 0) {
            found = true;
            break;
        }
    }
    infile.close();

    if (!found) {
        cout << "\nError: Student with Roll Number '" << deleteRoll << "' not found.\n";
        return;
    }

    // Confirm deletion
    char confirm;
    cout << "Are you sure you want to permanently delete student with Roll Number '" << deleteRoll << "'? (y/n): ";
    cin >> confirm;
    cleanInputBuffer();

    if (confirm != 'y' && confirm != 'Y') {
        cout << "Deletion canceled.\n";
        return;
    }

    // Perform deletion using temp file
    ifstream srcFile(FILE_NAME, ios::binary);
    ofstream tempFile("temp.dat", ios::binary);

    if (!srcFile || !tempFile) {
        cout << "Error: File operation failed. Unable to delete record.\n";
        return;
    }

    while (srcFile.read(reinterpret_cast<char*>(&s), sizeof(Student))) {
        if (strcmp(s.getRollNumber(), deleteRoll) != 0) {
            tempFile.write(reinterpret_cast<char*>(&s), sizeof(Student));
        }
    }

    srcFile.close();
    tempFile.close();

    // Remove old file and rename temp file to students.dat
    remove(FILE_NAME);
    rename("temp.dat", FILE_NAME);

    cout << "\nSuccess: Student record with Roll Number '" << deleteRoll << "' deleted successfully!\n";
}

// Feature 6 & Menu Controller: Menu navigation
void menu() {
    int choice;
    do {
        cout << "\n=========================================\n";
        cout << "       STUDENT MANAGEMENT SYSTEM         \n";
        cout << "=========================================\n";
        cout << "1. Add New Student Record\n";
        cout << "2. Display All Students Records\n";
        cout << "3. Search Student by Roll Number\n";
        cout << "4. Update Student Details\n";
        cout << "5. Delete Student Record\n";
        cout << "6. Exit Program\n";
        cout << "=========================================\n";
        cout << "Enter your choice (1-6): ";
        
        cin >> choice;

        if (cin.fail()) {
            cout << "Error: Invalid selection! Please enter a number between 1 and 6.\n";
            cleanInputBuffer();
            continue;
        }
        cleanInputBuffer(); // Clear newline from input buffer after reading number

        switch (choice) {
            case 1:
                addStudent();
                break;
            case 2:
                displayStudents();
                break;
            case 3:
                searchStudent();
                break;
            case 4:
                updateStudent();
                break;
            case 5:
                deleteStudent();
                break;
            case 6:
                cout << "\nThank you for using the Student Management System. Exiting...\n";
                break;
            default:
                cout << "Error: Option out of range. Please choose an option from 1 to 6.\n";
        }
    } while (choice != 6);
}
