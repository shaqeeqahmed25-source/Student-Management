export const cppSourceCode = `#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <limits>

using namespace std;

// Student Class Definition
class Student {
private:
    char rollNumber[20];
    char name[50];
    int age;
    char gender[15];
    char department[50];
    char year[15];
    char phone[20];
    char email[50];
    char address[100];
    double cgpa;

public:
    // Default Constructor
    Student() {
        strcpy(rollNumber, "");
        strcpy(name, "");
        age = 0;
        strcpy(gender, "");
        strcpy(department, "");
        strcpy(year, "");
        strcpy(phone, "");
        strcpy(email, "");
        strcpy(address, "");
        cgpa = 0.0;
    }

    // Parameterized Constructor
    Student(const char* r, const char* n, int a, const char* g, const char* dept, 
            const char* y, const char* p, const char* e, const char* addr, double c) {
        strncpy(rollNumber, r, 19); rollNumber[19] = '\\0';
        strncpy(name, n, 49); name[49] = '\\0';
        age = a;
        strncpy(gender, g, 14); gender[14] = '\\0';
        strncpy(department, dept, 49); department[49] = '\\0';
        strncpy(year, y, 14); year[14] = '\\0';
        strncpy(phone, p, 19); phone[19] = '\\0';
        strncpy(email, e, 49); email[49] = '\\0';
        strncpy(address, addr, 99); address[99] = '\\0';
        cgpa = c;
    }

    // Getters
    const char* getRollNumber() const { return rollNumber; }
    const char* getName() const { return name; }
    int getAge() const { return age; }
    const char* getGender() const { return gender; }
    const char* getDepartment() const { return department; }
    const char* getYear() const { return year; }
    const char* getPhone() const { return phone; }
    const char* getEmail() const { return email; }
    const char* getAddress() const { return address; }
    double getCGPA() const { return cgpa; }

    // Setters
    void setRollNumber(const char* r) { strncpy(rollNumber, r, 19); rollNumber[19] = '\\0'; }
    void setName(const char* n) { strncpy(name, n, 49); name[49] = '\\0'; }
    void setAge(int a) { age = a; }
    void setGender(const char* g) { strncpy(gender, g, 14); gender[14] = '\\0'; }
    void setDepartment(const char* dept) { strncpy(department, dept, 49); department[49] = '\\0'; }
    void setYear(const char* y) { strncpy(year, y, 14); year[14] = '\\0'; }
    void setPhone(const char* p) { strncpy(phone, p, 19); phone[19] = '\\0'; }
    void setEmail(const char* e) { strncpy(email, e, 49); email[49] = '\\0'; }
    void setAddress(const char* addr) { strncpy(address, addr, 99); address[99] = '\\0'; }
    void setCGPA(double c) { cgpa = c; }

    // Method to display student record in detail view
    void displayDetail() const {
        cout << "\\n=========================================\\n";
        cout << "            STUDENT RECORD DETAIL        \\n";
        cout << "=========================================\\n";
        cout << left << setw(18) << "Roll Number:" << rollNumber << "\\n";
        cout << left << setw(18) << "Name:" << name << "\\n";
        cout << left << setw(18) << "Age:" << age << " Years\\n";
        cout << left << setw(18) << "Gender:" << gender << "\\n";
        cout << left << setw(18) << "Department:" << department << "\\n";
        cout << left << setw(18) << "Academic Year:" << year << "\\n";
        cout << left << setw(18) << "Phone Number:" << phone << "\\n";
        cout << left << setw(18) << "Email Address:" << email << "\\n";
        cout << left << setw(18) << "Home Address:" << address << "\\n";
        cout << left << setw(18) << "CGPA:" << fixed << setprecision(2) << cgpa << " / 4.00\\n";
        cout << "=========================================\\n";
    }

    // Method to display student record in brief tabular row format
    void displayRow() const {
        cout << "| " << left << setw(12) << rollNumber 
             << "| " << left << setw(18) << name 
             << "| " << right << setw(3) << age 
             << " | " << left << setw(7) << gender 
             << "| " << left << setw(15) << department 
             << "| " << left << setw(8) << year 
             << "| " << right << setw(5) << fixed << setprecision(2) << cgpa << " |\\n";
    }
};

// Function Prototypes
void addStudent();
void displayStudents();
void searchStudent();
void updateStudent();
void deleteStudent();
void menu();
bool isRollNumberUnique(const char* rollNum);
void cleanInputBuffer();
bool validatePhone(const char* ph);
bool validateEmail(const char* em);

// Constants
const char* FILE_NAME = "students.dat";

int main() {
    menu();
    return 0;
}

// Helper: Clear standard input buffer
void cleanInputBuffer() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\\n');
}

// Helper: Check if roll number already exists in binary file
bool isRollNumberUnique(const char* rollNum) {
    ifstream infile(FILE_NAME, ios::binary);
    if (!infile) {
        return true; // File doesn't exist, so Roll Number is unique
    }
    
    Student temp;
    while (infile.read(reinterpret_cast<char*>(&temp), sizeof(Student))) {
        if (strcmp(temp.getRollNumber(), rollNum) == 0) {
            infile.close();
            return false; // Found match, not unique
        }
    }
    infile.close();
    return true;
}

// Helper: Simple validate for email
bool validateEmail(const char* em) {
    string emailStr(em);
    size_t atPos = emailStr.find('@');
    size_t dotPos = emailStr.find('.', atPos);
    return (atPos != string::npos && dotPos != string::npos && dotPos > atPos + 1);
}

// Helper: Simple validate for phone (numbers only, standard size)
bool validatePhone(const char* ph) {
    if (strlen(ph) < 5) return false;
    for (size_t i = 0; i < strlen(ph); ++i) {
        if (!isdigit(ph[i]) && ph[i] != '+' && ph[i] != '-' && ph[i] != ' ') {
            return false;
        }
    }
    return true;
}

// Feature 1: Add a New Student Record
void addStudent() {
    cout << "\\n=========================================\\n";
    cout << "           ADD NEW STUDENT RECORD        \\n";
    cout << "=========================================\\n";

    char rollNum[20];
    char name[50];
    int age;
    char gender[15];
    char dept[50];
    char year[15];
    char phone[20];
    char email[50];
    char addr[100];
    double cgpa;

    // Roll Number Input with uniqueness validation
    while (true) {
        cout << "Enter Roll Number (Unique): ";
        cin.getline(rollNum, 20);
        if (strlen(rollNum) == 0) {
            cout << "Error: Roll Number cannot be empty!\\n";
            continue;
        }
        if (!isRollNumberUnique(rollNum)) {
            cout << "Error: Student with Roll Number '" << rollNum << "' already exists!\\n";
            continue;
        }
        break;
    }

    // Name Input
    while (true) {
        cout << "Enter Name: ";
        cin.getline(name, 50);
        if (strlen(name) == 0) {
            cout << "Error: Name cannot be empty!\\n";
            continue;
        }
        break;
    }

    // Age Input
    while (true) {
        cout << "Enter Age: ";
        cin >> age;
        if (cin.fail() || age <= 0 || age > 120) {
            cout << "Error: Please enter a valid age (1-120).\\n";
            cleanInputBuffer();
            continue;
        }
        cleanInputBuffer();
        break;
    }

    // Gender Input
    while (true) {
        cout << "Enter Gender (Male/Female/Other): ";
        cin.getline(gender, 15);
        if (strlen(gender) == 0) {
            cout << "Error: Gender cannot be empty!\\n";
            continue;
        }
        break;
    }

    // Department Input
    while (true) {
        cout << "Enter Department (e.g. Computer Science): ";
        cin.getline(dept, 50);
        if (strlen(dept) == 0) {
            cout << "Error: Department cannot be empty!\\n";
            continue;
        }
        break;
    }

    // Year Input
    while (true) {
        cout << "Enter Year (e.g., 1st Year, Sophomore): ";
        cin.getline(year, 15);
        if (strlen(year) == 0) {
            cout << "Error: Academic Year cannot be empty!\\n";
            continue;
        }
        break;
    }

    // Phone Input
    while (true) {
        cout << "Enter Phone Number: ";
        cin.getline(phone, 20);
        if (!validatePhone(phone)) {
            cout << "Error: Invalid phone format. Use digits, space, '+' or '-'.\\n";
            continue;
        }
        break;
    }

    // Email Input
    while (true) {
        cout << "Enter Email: ";
        cin.getline(email, 50);
        if (!validateEmail(email)) {
            cout << "Error: Invalid email format (example: name@domain.com).\\n";
            continue;
        }
        break;
    }

    // Address Input
    while (true) {
        cout << "Enter Address: ";
        cin.getline(addr, 100);
        if (strlen(addr) == 0) {
            cout << "Error: Address cannot be empty!\\n";
            continue;
        }
        break;
    }

    // CGPA Input
    while (true) {
        cout << "Enter CGPA (0.00 - 4.00): ";
        cin >> cgpa;
        if (cin.fail() || cgpa < 0.0 || cgpa > 4.0) {
            cout << "Error: Please enter a valid CGPA between 0.00 and 4.00.\\n";
            cleanInputBuffer();
            continue;
        }
        cleanInputBuffer();
        break;
    }

    // Construct Student Object
    Student newStudent(rollNum, name, age, gender, dept, year, phone, email, addr, cgpa);

    // Save record to file
    ofstream outfile(FILE_NAME, ios::binary | ios::app);
    if (!outfile) {
        cout << "\\nError: Critical system error! Unable to open data file for writing.\\n";
        return;
    }

    outfile.write(reinterpret_cast<char*>(&newStudent), sizeof(Student));
    outfile.close();

    cout << "\\nSuccess: Student record added successfully!\\n";
}

// Feature 2: Display All Student Records
void displayStudents() {
    ifstream infile(FILE_NAME, ios::binary);
    if (!infile) {
        cout << "\\n========================================================================================\\n";
        cout << "No student records found. The database file is currently empty or has not been created.\\n";
        cout << "========================================================================================\\n";
        return;
    }

    Student s;
    bool recordsFound = false;

    // Header structure
    cout << "\\n" << string(80, '=') << "\\n";
    cout << "                             LIST OF ALL STUDENTS RECORDS                               \\n";
    cout << string(80, '=') << "\\n";
    cout << "| " << left << setw(12) << "Roll Number" 
         << "| " << left << setw(18) << "Name" 
         << "| " << left << setw(3) << "Age" 
         << " | " << left << setw(7) << "Gender" 
         << "| " << left << setw(15) << "Department" 
         << "| " << left << setw(8) << "Year" 
         << "| " << left << setw(5) << "CGPA" << " |\\n";
    cout << string(80, '-') << "\\n";

    while (infile.read(reinterpret_cast<char*>(&s), sizeof(Student))) {
        s.displayRow();
        recordsFound = true;
    }
    infile.close();

    if (!recordsFound) {
        cout << "| No records available in the file.                                                    |\\n";
    }
    cout << string(80, '=') << "\\n";
}

// Feature 3: Search Student by Roll Number
void searchStudent() {
    cout << "\\n=========================================\\n";
    cout << "         SEARCH STUDENT RECORD           \\n";
    cout << "=========================================\\n";

    ifstream infile(FILE_NAME, ios::binary);
    if (!infile) {
        cout << "Error: No student records exist yet. Database file is empty.\\n";
        return;
    }

    char searchRoll[20];
    cout << "Enter Roll Number to search: ";
    cin.getline(searchRoll, 20);

    Student s;
    bool found = false;

    while (infile.read(reinterpret_cast<char*>(&s), sizeof(Student))) {
        if (strcmp(s.getRollNumber(), searchRoll) == 0) {
            s.displayDetail();
            found = true;
            break;
        }
    }
    infile.close();

    if (!found) {
        cout << "\\nError: Student with Roll Number '" << searchRoll << "' not found.\\n";
    }
}

// Feature 4: Update Student Details
void updateStudent() {
    cout << "\\n=========================================\\n";
    cout << "         UPDATE STUDENT DETAILS          \\n";
    cout << "=========================================\\n";

    fstream file(FILE_NAME, ios::binary | ios::in | ios::out);
    if (!file) {
        cout << "Error: No records found to update. File does not exist.\\n";
        return;
    }

    char updateRoll[20];
    cout << "Enter the Roll Number of the student to update: ";
    cin.getline(updateRoll, 20);

    Student s;
    bool found = false;
    streampos pos;

    while (true) {
        pos = file.tellg(); // Track current position of read pointer
        if (!file.read(reinterpret_cast<char*>(&s), sizeof(Student))) {
            break;
        }

        if (strcmp(s.getRollNumber(), updateRoll) == 0) {
            found = true;
            cout << "\\n--- Current Record Details ---";
            s.displayDetail();

            cout << "\\nEnter New Details (Leave empty/enter 0 to retain current value):\\n\\n";

            char name[50], gender[15], dept[50], year[15], phone[20], email[50], addr[100];
            string input;

            // Update Name
            cout << "Enter New Name [" << s.getName() << "]: ";
            cin.getline(name, 50);
            if (strlen(name) > 0) s.setName(name);

            // Update Age
            while (true) {
                cout << "Enter New Age [" << s.getAge() << "]: ";
                getline(cin, input);
                if (input.empty()) {
                    break; // Keep existing
                }
                try {
                    int newAge = stoi(input);
                    if (newAge > 0 && newAge <= 120) {
                        s.setAge(newAge);
                        break;
                    } else {
                        cout << "Error: Age must be between 1 and 120.\\n";
                    }
                } catch (...) {
                    cout << "Error: Please enter a valid number.\\n";
                }
            }

            // Update Gender
            cout << "Enter New Gender [" << s.getGender() << "]: ";
            cin.getline(gender, 15);
            if (strlen(gender) > 0) s.setGender(gender);

            // Update Department
            cout << "Enter New Department [" << s.getDepartment() << "]: ";
            cin.getline(dept, 50);
            if (strlen(dept) > 0) s.setDepartment(dept);

            // Update Year
            cout << "Enter New Academic Year [" << s.getYear() << "]: ";
            cin.getline(year, 15);
            if (strlen(year) > 0) s.setYear(year);

            // Update Phone
            while (true) {
                cout << "Enter New Phone Number [" << s.getPhone() << "]: ";
                cin.getline(phone, 20);
                if (strlen(phone) == 0) {
                    break; // Keep existing
                }
                if (validatePhone(phone)) {
                    s.setPhone(phone);
                    break;
                }
                cout << "Error: Invalid phone format. Try again.\\n";
            }

            // Update Email
            while (true) {
                cout << "Enter New Email [" << s.getEmail() << "]: ";
                cin.getline(email, 50);
                if (strlen(email) == 0) {
                    break; // Keep existing
                }
                if (validateEmail(email)) {
                    s.setEmail(email);
                    break;
                }
                cout << "Error: Invalid email format. Try again.\\n";
            }

            // Update Address
            cout << "Enter New Address [" << s.getAddress() << "]: ";
            cin.getline(addr, 100);
            if (strlen(addr) > 0) s.setAddress(addr);

            // Update CGPA
            while (true) {
                cout << "Enter New CGPA [" << s.getCGPA() << "]: ";
                getline(cin, input);
                if (input.empty()) {
                    break; // Keep existing
                }
                try {
                    double newCGPA = stod(input);
                    if (newCGPA >= 0.0 && newCGPA <= 4.0) {
                        s.setCGPA(newCGPA);
                        break;
                    } else {
                        cout << "Error: CGPA must be between 0.00 and 4.00.\\n";
                    }
                } catch (...) {
                    cout << "Error: Please enter a valid decimal number.\\n";
                }
            }

            // Write modified object back to same location
            file.seekp(pos); // Move write pointer to start of this record
            file.write(reinterpret_cast<char*>(&s), sizeof(Student));
            cout << "\\nSuccess: Student record updated successfully!\\n";
            break;
        }
    }
    file.close();

    if (!found) {
        cout << "\\nError: Student with Roll Number '" << updateRoll << "' not found.\\n";
    }
}

// Feature 5: Delete Student Record Safely using Temporary File
void deleteStudent() {
    cout << "\\n=========================================\\n";
    cout << "         DELETE STUDENT RECORD           \\n";
    cout << "=========================================\\n";

    ifstream infile(FILE_NAME, ios::binary);
    if (!infile) {
        cout << "Error: No records found to delete. File does not exist.\\n";
        return;
    }

    char deleteRoll[20];
    cout << "Enter the Roll Number of the student to delete: ";
    cin.getline(deleteRoll, 20);

    // Scan if student exists first
    Student s;
    bool found = false;
    while (infile.read(reinterpret_cast<char*>(&s), sizeof(Student))) {
        if (strcmp(s.getRollNumber(), deleteRoll) == 0) {
            found = true;
            break;
        }
    }
    infile.close();

    if (!found) {
        cout << "\\nError: Student with Roll Number '" << deleteRoll << "' not found.\\n";
        return;
    }

    // Confirm deletion
    char confirm;
    cout << "Are you sure you want to permanently delete student with Roll Number '" << deleteRoll << "'? (y/n): ";
    cin >> confirm;
    cleanInputBuffer();

    if (confirm != 'y' && confirm != 'Y') {
        cout << "Deletion canceled.\\n";
        return;
    }

    // Perform deletion using temp file
    ifstream srcFile(FILE_NAME, ios::binary);
    ofstream tempFile("temp.dat", ios::binary);

    if (!srcFile || !tempFile) {
        cout << "Error: File operation failed. Unable to delete record.\\n";
        return;
    }

    while (srcFile.read(reinterpret_cast<char*>(&s), sizeof(Student))) {
        if (strcmp(s.getRollNumber(), deleteRoll) != 0) {
            tempFile.write(reinterpret_cast<char*>(&s), sizeof(Student));
        }
    }

    srcFile.close();
    tempFile.close();

    // Remove old file and rename temp file to students.dat
    remove(FILE_NAME);
    rename("temp.dat", FILE_NAME);

    cout << "\\nSuccess: Student record with Roll Number '" << deleteRoll << "' deleted successfully!\\n";
}

// Feature 6 & Menu Controller: Menu navigation
void menu() {
    int choice;
    do {
        cout << "\\n=========================================\\n";
        cout << "       STUDENT MANAGEMENT SYSTEM         \\n";
        cout << "=========================================\\n";
        cout << "1. Add New Student Record\\n";
        cout << "2. Display All Students Records\\n";
        cout << "3. Search Student by Roll Number\\n";
        cout << "4. Update Student Details\\n";
        cout << "5. Delete Student Record\\n";
        cout << "6. Exit Program\\n";
        cout << "=========================================\\n";
        cout << "Enter your choice (1-6): ";
        
        cin >> choice;

        if (cin.fail()) {
            cout << "Error: Invalid selection! Please enter a number between 1 and 6.\\n";
            cleanInputBuffer();
            continue;
        }
        cleanInputBuffer(); // Clear newline from input buffer after reading number

        switch (choice) {
            case 1:
                addStudent();
                break;
            case 2:
                displayStudents();
                break;
            case 3:
                searchStudent();
                break;
            case 4:
                updateStudent();
                break;
            case 5:
                deleteStudent();
                break;
            case 6:
                cout << "\\nThank you for using the Student Management System. Exiting...\\n";
                break;
            default:
                cout << "Error: Option out of range. Please choose an option from 1 to 6.\\n";
        }
    } while (choice != 6);
}`;

export const asciiFlowchart = `
+-----------------------------------------------------------+
|                      PROGRAM START                        |
+-----------------------------------------------------------+
                              |
                              v
+-----------------------------------------------------------+
|                  LOAD "students.dat"                      |
|             (System prepares stream pointers)              |
+-----------------------------------------------------------+
                              |
                              v
             +---------------------------------+
             |        DISPLAY MENU OPTIONS     | <------------------+
             |  1. Add Student                 |                    |
             |  2. Display All                 |                    |
             |  3. Search Student              |                    |
             |  4. Update Details              |                    |
             |  5. Delete Student              |                    |
             |  6. Exit Program                |                    |
             +---------------------------------+                    |
                              |                                     |
                              v                                     |
             +---------------------------------+                    |
             |        GET USER CHOICE (1-6)    |                    |
             +---------------------------------+                    |
                              |                                     |
                              +----------+                          |
                              |          |                          |
                              v          v                          |
                       [Choice == 6?]  [Other Option?]              |
                             |               |                      |
                    +--------+               v                      |
                    | Yes                    |                      |
                    v                        v                      |
          +-------------------+    (Execute Choice via)             |
          |   EXIT PROGRAM    |    (    Switch-Case   )             |
          | (Close all files) |              |                      |
          +-------------------+              +----------------------+
                                             |
    +----------------------------------------+---------------------------------------+
    |                    |                   |                  |                    |
    v                    v                   v                  v                    v
[Choice == 1]       [Choice == 2]       [Choice == 3]      [Choice == 4]       [Choice == 5]
    |                    |                   |                  |                    |
    v                    v                   v                  v                    v
+---------------+   +---------------+   +---------------+  +---------------+   +---------------+
|  addStudent() |   |displayStudents|   |searchStudent()|  |updateStudent()|   |deleteStudent()|
+---------------+   +---------------+   +---------------+  +---------------+   +---------------+
    |                    |                   |                  |                    |
    v                    v                   v                  v                    v
- Get Roll Number   - Open read-only    - Input target     - Input target      - Input target
- Check uniqueness    ifstream            Roll Number        Roll Number         Roll Number
- Get detailed data - Loop and read     - Read file sequentially               - Create temporary
- Verify CGPA &       objects from      - Match? Display   - Match?            - Copy all other
  email formatting    binary block        details            Get input changes   records to temp
- Write object block- Display formatted - Found? Error if  - Write updated     - Replace original
  using ofstream      tabular list        not found          struct to sector    file with temp
    |                    |                   |                  |                    |
    +--------------------+-------------------+------------------+--------------------+
                                             |
                                             v
                                   [Loop back to Menu]
`;

export const algorithmDocs = [
  {
    title: "1. Main Controller & Navigation (menu() / main())",
    steps: [
      "Initialize standard console input and output modes.",
      "Enter a continuous menu loop: Display options 1 to 6 on-screen.",
      "Read choice from input buffer.",
      "Validate choice: check if stream has failed or input is out of range. Run recovery clear (`cin.clear()` and discard stream buffer) on error.",
      "Dispatch choice using switch-case routing to the relevant sub-function.",
      "If choice is 6, print an exit greeting, terminate loop, and return 0 (safe exit)."
    ]
  },
  {
    title: "2. Add Student Record (addStudent())",
    steps: [
      "Open database file 'students.dat' in append and binary mode: `ofstream outfile(FILE_NAME, ios::binary | ios::app)`.",
      "Prompt and read user's Roll Number. Query existing records to confirm this Roll Number does not already exist.",
      "Prompt and read Student Name. Verify name string is not empty.",
      "Prompt and read Age. Perform safety validation check (must be an integer within 1 and 120 inclusive).",
      "Prompt and read Gender, Department, and Academic Year (e.g., 'Sophomore').",
      "Prompt and read Phone Number and Email. Verify correct formats via custom string parsing (ensuring '@' and '.' are aligned in email and only numerical dial symbols are used in phone).",
      "Prompt and read Address and CGPA (must be a float between 0.00 and 4.00 inclusive).",
      "Instantiate a local `Student` object passing these valid values to the constructor.",
      "Write the complete contiguous memory block representing the `Student` object block to the file stream: `outfile.write((char*)&newStudent, sizeof(Student))`.",
      "Close file stream, display success message, and return to the main menu."
    ]
  },
  {
    title: "3. Display All Records (displayStudents())",
    steps: [
      "Open database file 'students.dat' in read-only binary mode: `ifstream infile(FILE_NAME, ios::binary)`.",
      "If the input stream fails to open, output that the database is empty or has not been instantiated, then exit function.",
      "Print a tabular header with centered titles and structured borders utilizing dynamic spacing formatting (`setw`).",
      "Execute a reading loop: `while(infile.read((char*)&temp, sizeof(Student)))`.",
      "For each student read, trigger `temp.displayRow()` which formats and prints its field arrays inside a custom ASCII-bordered row.",
      "Keep track of records counted. If count is 0, display an empty notice.",
      "Close the file input stream."
    ]
  },
  {
    title: "4. Search Record by Roll Number (searchStudent())",
    steps: [
      "Open database file 'students.dat' in read-only binary mode.",
      "If file can't be opened, output a search failure error stating zero records exist.",
      "Prompt user for target Roll Number.",
      "Initiate sequential scan: read records one-by-one from the stream.",
      "Compare target Roll Number with the active record's roll number using `strcmp`.",
      "If matched: trigger `displayDetail()` to print an elegant full-screen vertical bento-box panel of all fields. Set found flag to true and terminate search loop.",
      "If loop terminates without a match, output an error message stating record could not be found.",
      "Close the file stream."
    ]
  },
  {
    title: "5. Update Record (updateStudent())",
    steps: [
      "Open 'students.dat' in read-write binary mode: `fstream file(FILE_NAME, ios::binary | ios::in | ios::out)`.",
      "Prompt user for Roll Number of student record to modify.",
      "Scan sequentially through file while keeping track of current file cursor position using `file.tellg()`.",
      "Read record into local temporary `Student` object.",
      "If roll number matches, set found flag to true, present current record values, and prompt user for updates field-by-field.",
      "For each field, if user presses Enter directly (empty line), preserve the existing field value. Otherwise, validate the new input format and set the updated value.",
      "Seek the write cursor pointer `seekp` back to the stored position representing the start of this specific record.",
      "Write the updated Student object block over the old memory slot: `file.write((char*)&s, sizeof(Student))`.",
      "Close file stream, output success message, and break loop."
    ]
  },
  {
    title: "6. Delete Record safely (deleteStudent())",
    steps: [
      "Open source database file 'students.dat' in read-only binary mode.",
      "Prompt user for Roll Number to remove.",
      "Read file to verify if a matching record exists. If not found, close stream and return failure error.",
      "Confirm permanent deletion action with user via a (y/n) confirmation prompt.",
      "Open a temporary binary file 'temp.dat' in write-only mode.",
      "Open the original 'students.dat' again in read-only mode.",
      "Iterate through original file, reading each record block. If a record's roll number does not match the deletion target, write it immediately to 'temp.dat'.",
      "If the roll number matches, skip the write instruction (thus filtering it out of the new dataset).",
      "Close both file streams.",
      "Invoke standard filesystem functions to delete the stale 'students.dat': `remove(\"students.dat\")`.",
      "Rename 'temp.dat' to 'students.dat' to finalize the change: `rename(\"temp.dat\", \"students.dat\")`."
    ]
  }
];

export const functionExplanations = [
  {
    name: "Student::Student()",
    description: "Default constructor initializing all character arrays to empty strings and numeric variables (age, CGPA) to zero, ensuring clean memory and avoiding undefined behavior."
  },
  {
    name: "Student::Student(char*, char*, int, char*, ...)",
    description: "Parameterized constructor that cleanly initializes all student fields using safe string manipulation with size-bounded 'strncpy' and manual null-termination to prevent string overflow."
  },
  {
    name: "isRollNumberUnique(const char*)",
    description: "Crucial validation helper. Opens the binary file, scans all student structures, and compares their Roll Numbers. Returns false if a duplicate is found, protecting the primary key constraint."
  },
  {
    name: "addStudent()",
    description: "Handles comprehensive user input gathering, runs formatting checks (Age ranges, Email standard validation, Unique Roll Number), instantiates a Student object, and writes its contiguous raw binary layout to the end of students.dat using ios::app."
  },
  {
    name: "displayStudents()",
    description: "Reads the binary file from beginning to end, parsing records sequentially. Renders student details in a highly structured, perfectly aligned ASCII table using 'setw' and tabular separators."
  },
  {
    name: "searchStudent()",
    description: "Asks for a Roll Number, searches the file stream, and if found, displays all available details (including full home address, email, and phone) in an elegant bento card display panel."
  },
  {
    name: "updateStudent()",
    description: "Retrieves a record, displays its current values, and selectively accepts new values. Utilizes fstream seekp and tellg file pointers to overwrite the exact binary block in place."
  },
  {
    name: "deleteStudent()",
    description: "Safely filters out a record. It writes all non-matching records to a new 'temp.dat' file, removes 'students.dat' from the filesystem, and renames 'temp.dat' to replace it, preventing memory fragmentation."
  },
  {
    name: "validateEmail() & validatePhone()",
    description: "Algorithmic string-processing helper functions that enforce rigid validation constraints on emails (checks for @ and dot positions) and phone formats (checks for digits and symbols), preventing corrupt records."
  }
];

export const complexityData = [
  {
    operation: "Add Student Record",
    complexity: "O(N) *",
    description: "Appending a record is O(1), but since we must verify that the Roll Number is unique, we perform a sequential scan over all N existing records, yielding an overall time complexity of O(N)."
  },
  {
    operation: "Display All Records",
    complexity: "O(N)",
    description: "Requires traversing and reading all N student records currently stored in the binary file to construct the tabular table, resulting in a linear O(N) complexity."
  },
  {
    operation: "Search Student by Roll",
    complexity: "O(N)",
    description: "Performs a sequential search scanning from the beginning of the binary file to the end. In the worst case (record at the end or not present), it searches N records. (Average case: O(N/2))."
  },
  {
    operation: "Update Student Details",
    complexity: "O(N)",
    description: "Sequentially scans the file to locate the matching Roll Number (O(N)), performs updates on the cached object in memory, and then does an in-place write (O(1)) at the pinpointed stream position."
  },
  {
    operation: "Delete Student Record",
    complexity: "O(N)",
    description: "Reads and copies all N records (except the deleted one) to a temporary file. This requires reading N blocks and writing N-1 blocks, leading to a linear O(N) execution time."
  }
];

export const advantages = [
  {
    title: "Object-Oriented Integrity",
    text: "Encapsulates student attributes and record display behaviors within a singular, secure Student class, respecting SOLID engineering principles."
  },
  {
    title: "Direct Binary Serialization",
    text: "Writes fixed-size C-style memory structs directly to students.dat. This bypasses the overhead of text-parsing and provides ultra-fast loading speeds since data is saved exactly as it lives in memory."
  },
  {
    title: "Robust Input Sanity & Verification",
    text: "Validates email structures, locks down age thresholds, filters phone character styles, validates CGPA floats, and enforces Roll Number uniqueness to prevent corrupt database states."
  },
  {
    title: "In-Place Modification (fstream)",
    text: "Updates records in-place by dynamically calculating stream offsets using stream indicators (seekg/tellg/seekp). This avoids rewriting the entire database for minor edits, demonstrating efficient file handling."
  },
  {
    title: "Zero External Dependencies",
    text: "Constructed using purely standard C++ Standard Template Library (STL) headers. Fully cross-compatible with any g++, Clang, or MSVC compiler, rendering it completely portable."
  }
];

export const limitations = [
  {
    title: "Linear Sequential Scan Overhead",
    text: "Since records are stored sequentially in a flat binary file, searches and duplicate checks run in O(N) time. There is no B-Tree indexing or hash indexing, making it slow for massive datasets of 100,000+ students."
  },
  {
    title: "Fixed-Size String Allocation Waste",
    text: "Attributes like Names and Addresses use fixed character arrays (e.g., char address[100]) to maintain fixed-size struct frames for file handling. This leads to internal memory fragmentation when short strings are stored."
  },
  {
    title: "Concurrent Access Collisions",
    text: "The flat file is prone to corruption if accessed concurrently. C++ file streams lack transaction locking (ACID compliance) and row-level locks, meaning multiple processes writing simultaneously will corrupt the data."
  }
];

export const futureEnhancements = [
  {
    title: "Indexing System (B-Tree or Hash Map)",
    text: "Build an active in-memory index of Roll Numbers mapped to byte offsets. This will upgrade the O(N) search and duplicate-check complexity to O(1) or O(log N) speeds."
  },
  {
    title: "Dynamic Encryption (AES)",
    text: "Integrate encryption/decryption layers during write/read operations. This will protect students.dat records from raw external hexadecimal inspections, securing sensitive student details."
  },
  {
    title: "Relational Integration (SQLite/Drizzle)",
    text: "Migrate the physical file layer to a relational database like SQLite. This natively handles ACID transactions, concurrent execution, flexible schemas, and relational integrity keys."
  }
];
