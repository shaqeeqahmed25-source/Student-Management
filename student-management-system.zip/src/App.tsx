import React, { useState, useEffect, useRef } from 'react';
import { 
  Terminal, 
  Code, 
  BookOpen, 
  Copy, 
  Check, 
  PlusCircle, 
  Search, 
  RefreshCw, 
  Trash2, 
  UserPlus, 
  HelpCircle, 
  Database, 
  ArrowRight,
  Sparkles,
  Award,
  ChevronRight,
  Info,
  Layers,
  Zap,
  ShieldCheck,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  cppSourceCode, 
  asciiFlowchart, 
  algorithmDocs, 
  functionExplanations, 
  complexityData, 
  advantages, 
  limitations, 
  futureEnhancements 
} from './data';

interface StudentRecord {
  rollNumber: string;
  name: string;
  age: number;
  gender: string;
  department: string;
  year: string;
  phone: string;
  email: string;
  address: string;
  cgpa: number;
}

const initialStudents: StudentRecord[] = [
  {
    rollNumber: "101",
    name: "John Doe",
    age: 20,
    gender: "Male",
    department: "Computer Science",
    year: "Sophomore",
    phone: "+1 555-0192",
    email: "john.doe@university.edu",
    address: "123 University Ave, Boston, MA",
    cgpa: 3.85
  },
  {
    rollNumber: "102",
    name: "Alice Smith",
    age: 21,
    gender: "Female",
    department: "Electrical Eng",
    year: "Junior",
    phone: "+1 555-0143",
    email: "alice.s@university.edu",
    address: "456 Oak Street, Boston, MA",
    cgpa: 3.92
  },
  {
    rollNumber: "103",
    name: "Michael Brown",
    age: 19,
    gender: "Male",
    department: "Mechanical Eng",
    year: "Freshman",
    phone: "+1 555-0187",
    email: "mbrown@university.edu",
    address: "789 Pine Road, Boston, MA",
    cgpa: 3.40
  }
];

type TerminalState = 
  | 'menu'
  | 'add_roll' | 'add_name' | 'add_age' | 'add_gender' | 'add_dept' | 'add_year' | 'add_phone' | 'add_email' | 'add_addr' | 'add_cgpa'
  | 'search_roll'
  | 'update_roll' | 'update_name' | 'update_age' | 'update_gender' | 'update_dept' | 'update_year' | 'update_phone' | 'update_email' | 'update_addr' | 'update_cgpa'
  | 'delete_roll' | 'delete_confirm'
  | 'exited';

export default function App() {
  const [activeTab, setActiveTab] = useState<'terminal' | 'cpp' | 'docs'>('terminal');
  const [terminalTheme, setTerminalTheme] = useState<'phosphor' | 'amber' | 'cyberpunk' | 'classic'>('phosphor');
  
  // Database state
  const [students, setStudents] = useState<StudentRecord[]>(() => {
    const saved = localStorage.getItem('sms_students');
    return saved ? JSON.parse(saved) : initialStudents;
  });

  useEffect(() => {
    localStorage.setItem('sms_students', JSON.stringify(students));
  }, [students]);

  // Terminal Simulator State
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    "=========================================",
    "       STUDENT MANAGEMENT SYSTEM         ",
    "=========================================",
    "1. Add New Student Record",
    "2. Display All Students Records",
    "3. Search Student by Roll Number",
    "4. Update Student Details",
    "5. Delete Student Record",
    "6. Exit Program",
    "========================================="
  ]);
  const [terminalPrompt, setTerminalPrompt] = useState<string>("Enter your choice (1-6): ");
  const [terminalState, setTerminalState] = useState<TerminalState>('menu');
  const [inputValue, setInputValue] = useState<string>("");
  
  // Staging state for new student entry
  const [stagingStudent, setStagingStudent] = useState<Partial<StudentRecord>>({});
  
  // Target index or record we are updating
  const [targetRoll, setTargetRoll] = useState<string>("");
  const [updatingStudent, setUpdatingStudent] = useState<Partial<StudentRecord>>({});

  // Code Copy State
  const [copied, setCopied] = useState(false);

  const terminalEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll terminal on new logs
  useEffect(() => {
    if (terminalEndRef.current) {
      terminalEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [terminalLogs, terminalPrompt]);

  // Keep terminal input focused on wrapper click
  const focusTerminalInput = () => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  useEffect(() => {
    focusTerminalInput();
  }, [terminalState, activeTab]);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(cppSourceCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const clearTerminal = () => {
    setTerminalLogs(["[Console Cleared]"]);
    setTerminalPrompt("Enter your choice (1-6): ");
    setTerminalState('menu');
    setStagingStudent({});
    setUpdatingStudent({});
    setTargetRoll("");
  };

  const resetDatabase = () => {
    if (window.confirm("Are you sure you want to reset the database to the 3 standard default student records?")) {
      setStudents(initialStudents);
      appendLog("System: Initialized 'students.dat' with 3 default records.");
    }
  };

  const appendLog = (text: string) => {
    setTerminalLogs(prev => [...prev, text]);
  };

  // Helper validation functions
  const validatePhone = (ph: string): boolean => {
    if (ph.length < 5) return false;
    return /^[0-9+\-\s]+$/.test(ph);
  };

  const validateEmail = (em: string): boolean => {
    return em.includes('@') && em.includes('.') && em.indexOf('.') > em.indexOf('@') + 1;
  };

  const printMainMenu = () => {
    setTerminalLogs(prev => [
      ...prev,
      "",
      "=========================================",
      "       STUDENT MANAGEMENT SYSTEM         ",
      "=========================================",
      "1. Add New Student Record",
      "2. Display All Students Records",
      "3. Search Student by Roll Number",
      "4. Update Student Details",
      "5. Delete Student Record",
      "6. Exit Program",
      "========================================="
    ]);
    setTerminalPrompt("Enter your choice (1-6): ");
    setTerminalState('menu');
  };

  const processTerminalInput = (input: string) => {
    const trimmedInput = input.trim();
    
    // Add command input to log history so it looks realistic
    setTerminalLogs(prev => [...prev, `${terminalPrompt}${input}`]);
    setInputValue("");

    switch (terminalState) {
      case 'exited':
        // Press enter to restart
        printMainMenu();
        return;

      case 'menu':
        if (trimmedInput === '1') {
          setTerminalLogs(prev => [
            ...prev,
            "",
            "=========================================",
            "           ADD NEW STUDENT RECORD        ",
            "========================================="
          ]);
          setTerminalPrompt("Enter Roll Number (Unique): ");
          setTerminalState('add_roll');
        } 
        else if (trimmedInput === '2') {
          // Display tabular records
          setTerminalLogs(prev => [
            ...prev,
            "",
            "==========================================================================================",
            "                             LIST OF ALL STUDENTS RECORDS                                 ",
            "==========================================================================================",
            `| ${"Roll Number".padEnd(12)} | ${"Name".padEnd(18)} | Age | Gender  | ${"Department".padEnd(15)} | ${"Year".padEnd(8)} | CGPA  |`,
            "------------------------------------------------------------------------------------------"
          ]);

          if (students.length === 0) {
            setTerminalLogs(prev => [...prev, "| No records available in the 'students.dat' binary file.                               |"]);
          } else {
            students.forEach(s => {
              const rNum = s.rollNumber.padEnd(12);
              const name = s.name.substring(0, 18).padEnd(18);
              const age = s.age.toString().padStart(3);
              const gender = s.gender.substring(0, 7).padEnd(7);
              const dept = s.department.substring(0, 15).padEnd(15);
              const yr = s.year.substring(0, 8).padEnd(8);
              const cg = s.cgpa.toFixed(2).padStart(5);
              
              setTerminalLogs(prev => [...prev, `| ${rNum} | ${name} | ${age} | ${gender} | ${dept} | ${yr} | ${cg} |`]);
            });
          }
          setTerminalLogs(prev => [...prev, "=========================================================================================="]);
          
          // Re-prompt menu
          printMainMenu();
        } 
        else if (trimmedInput === '3') {
          setTerminalLogs(prev => [
            ...prev,
            "",
            "=========================================",
            "         SEARCH STUDENT RECORD           ",
            "========================================="
          ]);
          setTerminalPrompt("Enter Roll Number to search: ");
          setTerminalState('search_roll');
        } 
        else if (trimmedInput === '4') {
          setTerminalLogs(prev => [
            ...prev,
            "",
            "=========================================",
            "         UPDATE STUDENT DETAILS          ",
            "========================================="
          ]);
          setTerminalPrompt("Enter the Roll Number of the student to update: ");
          setTerminalState('update_roll');
        } 
        else if (trimmedInput === '5') {
          setTerminalLogs(prev => [
            ...prev,
            "",
            "=========================================",
            "         DELETE STUDENT RECORD           ",
            "========================================="
          ]);
          setTerminalPrompt("Enter the Roll Number of the student to delete: ");
          setTerminalState('delete_roll');
        } 
        else if (trimmedInput === '6') {
          setTerminalLogs(prev => [
            ...prev,
            "",
            "Thank you for using the Student Management System. Exiting...",
            "System process terminated safely. [students.dat closed]",
            "----------------------------------------",
            "Press [ENTER] to boot the program again."
          ]);
          setTerminalPrompt("> ");
          setTerminalState('exited');
        } 
        else {
          setTerminalLogs(prev => [
            ...prev,
            "Error: Invalid selection! Please enter a number between 1 and 6."
          ]);
          setTerminalPrompt("Enter your choice (1-6): ");
        }
        break;

      // ADD STUDENT RECORDS PIPELINE
      case 'add_roll':
        if (!trimmedInput) {
          setTerminalLogs(prev => [...prev, "Error: Roll Number cannot be empty!"]);
          setTerminalPrompt("Enter Roll Number (Unique): ");
          return;
        }
        // Unique Check
        if (students.some(s => s.rollNumber.toLowerCase() === trimmedInput.toLowerCase())) {
          setTerminalLogs(prev => [...prev, `Error: Student with Roll Number '${trimmedInput}' already exists!`]);
          setTerminalPrompt("Enter Roll Number (Unique): ");
          return;
        }
        setStagingStudent({ rollNumber: trimmedInput });
        setTerminalPrompt("Enter Name: ");
        setTerminalState('add_name');
        break;

      case 'add_name':
        if (!trimmedInput) {
          setTerminalLogs(prev => [...prev, "Error: Name cannot be empty!"]);
          setTerminalPrompt("Enter Name: ");
          return;
        }
        setStagingStudent(prev => ({ ...prev, name: trimmedInput }));
        setTerminalPrompt("Enter Age: ");
        setTerminalState('add_age');
        break;

      case 'add_age':
        const parsedAge = parseInt(trimmedInput, 10);
        if (isNaN(parsedAge) || parsedAge <= 0 || parsedAge > 120) {
          setTerminalLogs(prev => [...prev, "Error: Please enter a valid age (1-120)."]);
          setTerminalPrompt("Enter Age: ");
          return;
        }
        setStagingStudent(prev => ({ ...prev, age: parsedAge }));
        setTerminalPrompt("Enter Gender (Male/Female/Other): ");
        setTerminalState('add_gender');
        break;

      case 'add_gender':
        if (!trimmedInput) {
          setTerminalLogs(prev => [...prev, "Error: Gender cannot be empty!"]);
          setTerminalPrompt("Enter Gender (Male/Female/Other): ");
          return;
        }
        setStagingStudent(prev => ({ ...prev, gender: trimmedInput }));
        setTerminalPrompt("Enter Department (e.g. Computer Science): ");
        setTerminalState('add_dept');
        break;

      case 'add_dept':
        if (!trimmedInput) {
          setTerminalLogs(prev => [...prev, "Error: Department cannot be empty!"]);
          setTerminalPrompt("Enter Department (e.g. Computer Science): ");
          return;
        }
        setStagingStudent(prev => ({ ...prev, department: trimmedInput }));
        setTerminalPrompt("Enter Year (e.g., 1st Year, Sophomore): ");
        setTerminalState('add_year');
        break;

      case 'add_year':
        if (!trimmedInput) {
          setTerminalLogs(prev => [...prev, "Error: Academic Year cannot be empty!"]);
          setTerminalPrompt("Enter Year (e.g., 1st Year, Sophomore): ");
          return;
        }
        setStagingStudent(prev => ({ ...prev, year: trimmedInput }));
        setTerminalPrompt("Enter Phone Number: ");
        setTerminalState('add_phone');
        break;

      case 'add_phone':
        if (!validatePhone(trimmedInput)) {
          setTerminalLogs(prev => [...prev, "Error: Invalid phone format. Use digits, space, '+' or '-'."]);
          setTerminalPrompt("Enter Phone Number: ");
          return;
        }
        setStagingStudent(prev => ({ ...prev, phone: trimmedInput }));
        setTerminalPrompt("Enter Email: ");
        setTerminalState('add_email');
        break;

      case 'add_email':
        if (!validateEmail(trimmedInput)) {
          setTerminalLogs(prev => [...prev, "Error: Invalid email format (example: name@domain.com)."]);
          setTerminalPrompt("Enter Email: ");
          return;
        }
        setStagingStudent(prev => ({ ...prev, email: trimmedInput }));
        setTerminalPrompt("Enter Address: ");
        setTerminalState('add_addr');
        break;

      case 'add_addr':
        if (!trimmedInput) {
          setTerminalLogs(prev => [...prev, "Error: Address cannot be empty!"]);
          setTerminalPrompt("Enter Address: ");
          return;
        }
        setStagingStudent(prev => ({ ...prev, address: trimmedInput }));
        setTerminalPrompt("Enter CGPA (0.00 - 4.00): ");
        setTerminalState('add_cgpa');
        break;

      case 'add_cgpa':
        const parsedCgpa = parseFloat(trimmedInput);
        if (isNaN(parsedCgpa) || parsedCgpa < 0.0 || parsedCgpa > 4.0) {
          setTerminalLogs(prev => [...prev, "Error: Please enter a valid CGPA between 0.00 and 4.00."]);
          setTerminalPrompt("Enter CGPA (0.00 - 4.00): ");
          return;
        }

        // Complete creation
        const finalStudent: StudentRecord = {
          rollNumber: stagingStudent.rollNumber!,
          name: stagingStudent.name!,
          age: stagingStudent.age!,
          gender: stagingStudent.gender!,
          department: stagingStudent.department!,
          year: stagingStudent.year!,
          phone: stagingStudent.phone!,
          email: stagingStudent.email!,
          address: stagingStudent.address!,
          cgpa: parsedCgpa
        };

        setStudents(prev => [...prev, finalStudent]);
        setTerminalLogs(prev => [
          ...prev,
          "",
          "Success: Student record added successfully!",
          "[Data serialized & appended to students.dat binary storage]"
        ]);
        setStagingStudent({});
        printMainMenu();
        break;

      // SEARCH PIPELINE
      case 'search_roll':
        if (!trimmedInput) {
          setTerminalLogs(prev => [...prev, "Error: Search Roll Number cannot be empty!"]);
          setTerminalPrompt("Enter Roll Number to search: ");
          return;
        }
        const matchedStudent = students.find(s => s.rollNumber.toLowerCase() === trimmedInput.toLowerCase());
        if (matchedStudent) {
          setTerminalLogs(prev => [
            ...prev,
            "",
            "=========================================",
            "            STUDENT RECORD DETAIL        ",
            "=========================================",
            `Roll Number:       ${matchedStudent.rollNumber}`,
            `Name:              ${matchedStudent.name}`,
            `Age:               ${matchedStudent.age} Years`,
            `Gender:            ${matchedStudent.gender}`,
            `Department:        ${matchedStudent.department}`,
            `Academic Year:     ${matchedStudent.year}`,
            `Phone Number:      ${matchedStudent.phone}`,
            `Email Address:     ${matchedStudent.email}`,
            `Home Address:      ${matchedStudent.address}`,
            `CGPA:              ${matchedStudent.cgpa.toFixed(2)} / 4.00`,
            "========================================="
          ]);
        } else {
          setTerminalLogs(prev => [...prev, `\nError: Student with Roll Number '${trimmedInput}' not found.`]);
        }
        printMainMenu();
        break;

      // UPDATE PIPELINE
      case 'update_roll':
        if (!trimmedInput) {
          setTerminalLogs(prev => [...prev, "Error: Roll Number cannot be empty!"]);
          setTerminalPrompt("Enter the Roll Number of the student to update: ");
          return;
        }
        const toUpdate = students.find(s => s.rollNumber.toLowerCase() === trimmedInput.toLowerCase());
        if (!toUpdate) {
          setTerminalLogs(prev => [...prev, `\nError: Student with Roll Number '${trimmedInput}' not found.`]);
          printMainMenu();
          return;
        }
        
        setTargetRoll(toUpdate.rollNumber);
        setUpdatingStudent({ ...toUpdate });
        
        setTerminalLogs(prev => [
          ...prev,
          `Found: ${toUpdate.name} (${toUpdate.department})`,
          "Enter New Details (Leave empty to retain current value):"
        ]);
        setTerminalPrompt(`Enter New Name [${toUpdate.name}]: `);
        setTerminalState('update_name');
        break;

      case 'update_name':
        if (trimmedInput) {
          setUpdatingStudent(prev => ({ ...prev, name: trimmedInput }));
        }
        setTerminalPrompt(`Enter New Age [${updatingStudent.age}]: `);
        setTerminalState('update_age');
        break;

      case 'update_age':
        if (trimmedInput) {
          const uAge = parseInt(trimmedInput, 10);
          if (isNaN(uAge) || uAge <= 0 || uAge > 120) {
            setTerminalLogs(prev => [...prev, "Error: Age must be between 1 and 120."]);
            setTerminalPrompt(`Enter New Age [${updatingStudent.age}]: `);
            return;
          }
          setUpdatingStudent(prev => ({ ...prev, age: uAge }));
        }
        setTerminalPrompt(`Enter New Gender [${updatingStudent.gender}]: `);
        setTerminalState('update_gender');
        break;

      case 'update_gender':
        if (trimmedInput) {
          setUpdatingStudent(prev => ({ ...prev, gender: trimmedInput }));
        }
        setTerminalPrompt(`Enter New Department [${updatingStudent.department}]: `);
        setTerminalState('update_dept');
        break;

      case 'update_dept':
        if (trimmedInput) {
          setUpdatingStudent(prev => ({ ...prev, department: trimmedInput }));
        }
        setTerminalPrompt(`Enter New Academic Year [${updatingStudent.year}]: `);
        setTerminalState('update_year');
        break;

      case 'update_year':
        if (trimmedInput) {
          setUpdatingStudent(prev => ({ ...prev, year: trimmedInput }));
        }
        setTerminalPrompt(`Enter New Phone Number [${updatingStudent.phone}]: `);
        setTerminalState('update_phone');
        break;

      case 'update_phone':
        if (trimmedInput) {
          if (!validatePhone(trimmedInput)) {
            setTerminalLogs(prev => [...prev, "Error: Invalid phone format. Try again."]);
            setTerminalPrompt(`Enter New Phone Number [${updatingStudent.phone}]: `);
            return;
          }
          setUpdatingStudent(prev => ({ ...prev, phone: trimmedInput }));
        }
        setTerminalPrompt(`Enter New Email [${updatingStudent.email}]: `);
        setTerminalState('update_email');
        break;

      case 'update_email':
        if (trimmedInput) {
          if (!validateEmail(trimmedInput)) {
            setTerminalLogs(prev => [...prev, "Error: Invalid email format. Try again."]);
            setTerminalPrompt(`Enter New Email [${updatingStudent.email}]: `);
            return;
          }
          setUpdatingStudent(prev => ({ ...prev, email: trimmedInput }));
        }
        setTerminalPrompt(`Enter New Address [${updatingStudent.address}]: `);
        setTerminalState('update_addr');
        break;

      case 'update_addr':
        if (trimmedInput) {
          setUpdatingStudent(prev => ({ ...prev, address: trimmedInput }));
        }
        setTerminalPrompt(`Enter New CGPA [${updatingStudent.cgpa?.toFixed(2)}]: `);
        setTerminalState('update_cgpa');
        break;

      case 'update_cgpa':
        if (trimmedInput) {
          const uCgpa = parseFloat(trimmedInput);
          if (isNaN(uCgpa) || uCgpa < 0.0 || uCgpa > 4.0) {
            setTerminalLogs(prev => [...prev, "Error: CGPA must be between 0.00 and 4.00."]);
            setTerminalPrompt(`Enter New CGPA [${updatingStudent.cgpa?.toFixed(2)}]: `);
            return;
          }
          setUpdatingStudent(prev => ({ ...prev, cgpa: uCgpa }));
        }

        // Apply Update
        setStudents(prev => 
          prev.map(s => s.rollNumber === targetRoll ? (updatingStudent as StudentRecord) : s)
        );
        
        setTerminalLogs(prev => [
          ...prev,
          "",
          "Success: Student record updated successfully!",
          `[Byte segment rewritten in students.dat at target block]`
        ]);
        
        setUpdatingStudent({});
        setTargetRoll("");
        printMainMenu();
        break;

      // DELETE PIPELINE
      case 'delete_roll':
        if (!trimmedInput) {
          setTerminalLogs(prev => [...prev, "Error: Roll Number cannot be empty!"]);
          setTerminalPrompt("Enter the Roll Number of the student to delete: ");
          return;
        }
        const toDelete = students.find(s => s.rollNumber.toLowerCase() === trimmedInput.toLowerCase());
        if (!toDelete) {
          setTerminalLogs(prev => [...prev, `\nError: Student with Roll Number '${trimmedInput}' not found.`]);
          printMainMenu();
          return;
        }

        setTargetRoll(toDelete.rollNumber);
        setTerminalPrompt(`Are you sure you want to permanently delete student with Roll Number '${toDelete.rollNumber}'? (y/n): `);
        setTerminalState('delete_confirm');
        break;

      case 'delete_confirm':
        if (trimmedInput.toLowerCase() === 'y') {
          setStudents(prev => prev.filter(s => s.rollNumber !== targetRoll));
          setTerminalLogs(prev => [
            ...prev,
            "",
            `Success: Student record with Roll Number '${targetRoll}' deleted successfully!`,
            "[Safe filter written to temp.dat, students.dat replaced]"
          ]);
        } else {
          setTerminalLogs(prev => [...prev, "Deletion canceled."]);
        }
        setTargetRoll("");
        printMainMenu();
        break;
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    processTerminalInput(inputValue);
  };

  // Helper helper to quickly inject text into the prompt
  const injectCommand = (cmd: string) => {
    processTerminalInput(cmd);
    focusTerminalInput();
  };

  const getTerminalThemeClasses = () => {
    switch (terminalTheme) {
      case 'phosphor':
        return {
          bg: 'bg-zinc-950 border-emerald-500/30',
          text: 'text-emerald-400 font-mono text-[14px]',
          caret: 'bg-emerald-400',
          heading: 'text-emerald-500 font-bold',
          scrollbar: 'scrollbar-emerald'
        };
      case 'amber':
        return {
          bg: 'bg-amber-950/90 border-amber-500/30',
          text: 'text-amber-400 font-mono text-[14px]',
          caret: 'bg-amber-400',
          heading: 'text-amber-500 font-bold',
          scrollbar: 'scrollbar-amber'
        };
      case 'cyberpunk':
        return {
          bg: 'bg-fuchsia-950/80 border-fuchsia-500/40 backdrop-blur-sm',
          text: 'text-cyan-300 font-mono text-[14px]',
          caret: 'bg-fuchsia-400',
          heading: 'text-fuchsia-400 font-bold',
          scrollbar: 'scrollbar-cyan'
        };
      case 'classic':
      default:
        return {
          bg: 'bg-slate-900 border-slate-700',
          text: 'text-slate-200 font-mono text-[14px]',
          caret: 'bg-slate-300',
          heading: 'text-white font-bold',
          scrollbar: 'scrollbar-slate'
        };
    }
  };

  const themeColors = getTerminalThemeClasses();

  return (
    <div className="flex h-screen w-screen bg-slate-50 text-slate-900 overflow-hidden font-sans" id="app_root">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col shrink-0" id="sidebar_nav">
        <div className="p-6 border-b border-slate-700 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-500 rounded flex items-center justify-center shrink-0">
              <span className="font-mono font-bold text-sm text-white">C++</span>
            </div>
            <h1 className="text-sm font-bold tracking-tight uppercase text-white">Student Manager</h1>
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          <div className="text-[10px] uppercase tracking-widest text-slate-500 font-bold px-3 pt-2 pb-1">App Panels</div>
          
          <div 
            onClick={() => setActiveTab('terminal')}
            className={`p-3 rounded-lg flex items-center gap-3 cursor-pointer border transition-all ${
              activeTab === 'terminal' 
                ? 'bg-blue-600/20 text-blue-400 border-blue-500/30 font-medium' 
                : 'text-slate-400 border-transparent hover:bg-slate-800 hover:text-slate-200'
            }`}
            id="sidebar_tab_terminal"
          >
            <Terminal className="w-4 h-4" />
            <span>Menu System</span>
          </div>

          <div 
            onClick={() => setActiveTab('cpp')}
            className={`p-3 rounded-lg flex items-center gap-3 cursor-pointer border transition-all ${
              activeTab === 'cpp' 
                ? 'bg-blue-600/20 text-blue-400 border-blue-500/30 font-medium' 
                : 'text-slate-400 border-transparent hover:bg-slate-800 hover:text-slate-200'
            }`}
            id="sidebar_tab_cpp"
          >
            <FileText className="w-4 h-4" />
            <span>C++ Source Code</span>
          </div>

          <div 
            onClick={() => setActiveTab('docs')}
            className={`p-3 rounded-lg flex items-center gap-3 cursor-pointer border transition-all ${
              activeTab === 'docs' 
                ? 'bg-blue-600/20 text-blue-400 border-blue-500/30 font-medium' 
                : 'text-slate-400 border-transparent hover:bg-slate-800 hover:text-slate-200'
            }`}
            id="sidebar_tab_docs"
          >
            <BookOpen className="w-4 h-4" />
            <span>Documentation Hub</span>
          </div>

          <div className="text-[10px] uppercase tracking-widest text-slate-500 font-bold px-3 pt-4 pb-1">C++ Compiler Actions</div>

          <div 
            onClick={() => {
              setActiveTab('terminal');
              if (terminalState === 'menu') {
                injectCommand("1");
              } else {
                appendLog("\nSystem Option: Resetting prompt to start new record insertion.");
                setTerminalPrompt("Enter Roll Number (Unique): ");
                setTerminalState('add_roll');
              }
            }}
            className="text-slate-400 p-3 flex items-center gap-3 hover:bg-slate-800 rounded-lg cursor-pointer hover:text-slate-200 transition-all text-sm"
            id="sidebar_action_add"
          >
            <PlusCircle className="w-4 h-4 text-slate-500" />
            <span>Add Student</span>
          </div>

          <div 
            onClick={() => {
              setActiveTab('terminal');
              if (terminalState === 'menu') {
                injectCommand("3");
              } else {
                setTerminalPrompt("Enter Roll Number to search: ");
                setTerminalState('search_roll');
              }
            }}
            className="text-slate-400 p-3 flex items-center gap-3 hover:bg-slate-800 rounded-lg cursor-pointer hover:text-slate-200 transition-all text-sm"
            id="sidebar_action_search"
          >
            <Search className="w-4 h-4 text-slate-500" />
            <span>Search Record</span>
          </div>

          <div 
            onClick={() => {
              setActiveTab('terminal');
              if (terminalState === 'menu') {
                injectCommand("4");
              } else {
                setTerminalPrompt("Enter the Roll Number of the student to update: ");
                setTerminalState('update_roll');
              }
            }}
            className="text-slate-400 p-3 flex items-center gap-3 hover:bg-slate-800 rounded-lg cursor-pointer hover:text-slate-200 transition-all text-sm"
            id="sidebar_action_update"
          >
            <RefreshCw className="w-4 h-4 text-slate-500" />
            <span>Update Details</span>
          </div>

          <div 
            onClick={() => {
              setActiveTab('terminal');
              if (terminalState === 'menu') {
                injectCommand("5");
              } else {
                setTerminalPrompt("Enter the Roll Number of the student to delete: ");
                setTerminalState('delete_roll');
              }
            }}
            className="text-slate-400 p-3 flex items-center gap-3 hover:bg-slate-800 rounded-lg cursor-pointer hover:text-slate-200 transition-all text-sm"
            id="sidebar_action_delete"
          >
            <Trash2 className="w-4 h-4 text-slate-500" />
            <span>Delete Student</span>
          </div>
        </nav>

        <div className="p-6 bg-slate-950 shrink-0 border-t border-slate-850">
          <div className="text-[10px] uppercase tracking-widest text-slate-500 mb-2 font-bold">System Status</div>
          <div className="flex items-center gap-2 text-xs">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
            <span className="text-emerald-400 font-mono">students.dat connected</span>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden" id="main_content">
        {/* Header */}
        <header className="h-20 bg-white border-b border-slate-200 px-8 flex items-center justify-between shrink-0">
          <div>
            <h2 className="text-xl font-bold text-slate-800">
              {activeTab === 'terminal' && "Interactive Compiler Console & Sandbox"}
              {activeTab === 'cpp' && "C++ Source Code Viewer"}
              {activeTab === 'docs' && "System Documentation & Algorithms"}
            </h2>
            <p className="text-xs text-slate-500">
              {activeTab === 'terminal' && `Simulating binary operations on 'students.dat' (${students.length * 344} bytes)`}
              {activeTab === 'cpp' && "Standard C++ fstream and custom aligned memory block representation"}
              {activeTab === 'docs' && "Comprehensive analysis of complexity, flowcharts, and file system formats"}
            </p>
          </div>
          <div className="flex gap-3">
            {activeTab === 'terminal' && (
              <>
                <button 
                  onClick={resetDatabase}
                  className="px-4 py-2 border border-slate-200 rounded-md text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 transition-all active:scale-95"
                  id="hdr_restore_defaults"
                >
                  Restore Defaults
                </button>
                <button 
                  onClick={() => {
                    const headers = ["Roll No", "Name", "Age", "Gender", "Department", "Year", "Phone", "Email", "Address", "CGPA"];
                    const rows = students.map(s => [
                      s.rollNumber, s.name, s.age, s.gender, s.department, s.year, s.phone, s.email, s.address, s.cgpa
                    ]);
                    const csvContent = "data:text/csv;charset=utf-8," 
                      + [headers.join(","), ...rows.map(e => e.map(val => `"${val}"`).join(","))].join("\n");
                    const encodedUri = encodeURI(csvContent);
                    const link = document.createElement("a");
                    link.setAttribute("href", encodedUri);
                    link.setAttribute("download", `students_binary_dump.csv`);
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    appendLog("System: Student records exported to local CSV format.");
                  }}
                  className="px-4 py-2 border border-slate-200 rounded-md text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 transition-all active:scale-95"
                  id="hdr_export_csv"
                >
                  Export CSV
                </button>
                <button 
                  onClick={() => {
                    if (terminalState === 'menu') {
                      const rolls = students.map(s => parseInt(s.rollNumber)).filter(n => !isNaN(n));
                      const nextRoll = (rolls.length ? Math.max(...rolls) + 1 : 104).toString();
                      const names = ["Sarah Connor", "Bruce Wayne", "Clark Kent", "Diana Prince", "Peter Parker"];
                      const depts = ["Cybernetics", "Business Admin", "Journalism", "Archeology", "Biochemistry"];
                      const randomIdx = Math.floor(Math.random() * names.length);
                      
                      const randomStudent: StudentRecord = {
                        rollNumber: nextRoll,
                        name: names[randomIdx],
                        age: 20 + Math.floor(Math.random() * 5),
                        gender: randomIdx === 0 || randomIdx === 3 ? "Female" : "Male",
                        department: depts[randomIdx],
                        year: "Junior",
                        phone: "+1 555-0210",
                        email: `${names[randomIdx].toLowerCase().replace(' ', '.')}@university.edu`,
                        address: "Gotham Heights, Sector 7",
                        cgpa: parseFloat((3.0 + Math.random() * 1.0).toFixed(2))
                      };
                      
                      setTerminalLogs(prev => [
                        ...prev,
                        `${terminalPrompt}1`,
                        "",
                        "=========================================",
                        "           ADD NEW STUDENT RECORD        ",
                        "=========================================",
                        `Enter Roll Number (Unique): ${randomStudent.rollNumber}`,
                        `Enter Name: ${randomStudent.name}`,
                        `Enter Age: ${randomStudent.age}`,
                        `Enter Gender (Male/Female/Other): ${randomStudent.gender}`,
                        `Enter Department: ${randomStudent.department}`,
                        `Enter Year: ${randomStudent.year}`,
                        `Enter Phone Number: ${randomStudent.phone}`,
                        `Enter Email: ${randomStudent.email}`,
                        `Enter Address: ${randomStudent.address}`,
                        `Enter CGPA (0.00 - 4.00): ${randomStudent.cgpa}`,
                        "",
                        "Success: Student record added successfully!",
                        "[Data serialized & appended to students.dat binary storage]"
                      ]);
                      setStudents(prev => [...prev, randomStudent]);
                      printMainMenu();
                    } else {
                      alert("Please complete or cancel your current terminal prompt before generating a quick student.");
                    }
                  }}
                  className="px-4 py-2 bg-slate-900 text-white hover:bg-slate-800 rounded-md text-sm font-medium transition-all active:scale-95 flex items-center gap-1.5"
                  id="hdr_add_student"
                >
                  <UserPlus className="w-4 h-4" />
                  Add New Student
                </button>
              </>
            )}
            
            {activeTab === 'cpp' && (
              <button 
                onClick={handleCopyCode}
                className="px-4 py-2 bg-slate-900 text-white rounded-md text-sm font-medium hover:bg-slate-800 transition-all active:scale-95 flex items-center gap-2"
                id="hdr_copy_code"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                {copied ? "Code Copied!" : "Copy Full main.cpp"}
              </button>
            )}
          </div>
        </header>

        {/* Stats Row */}
        <section className="p-8 grid grid-cols-1 md:grid-cols-4 gap-6 shrink-0" id="stats_row">
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
            <div className="text-slate-500 text-xs uppercase font-bold tracking-wider mb-1">Total Students</div>
            <div className="text-2xl font-bold text-slate-900">{students.length}</div>
          </div>
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
            <div className="text-slate-500 text-xs uppercase font-bold tracking-wider mb-1">Average CGPA</div>
            <div className="text-2xl font-bold text-slate-900">
              {(students.reduce((acc, s) => acc + s.cgpa, 0) / (students.length || 1)).toFixed(2)}
            </div>
          </div>
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
            <div className="text-slate-500 text-xs uppercase font-bold tracking-wider mb-1">Binary File Size</div>
            <div className="text-2xl font-bold text-slate-900">
              {((students.length * 344) / 1024).toFixed(1)} KB
            </div>
          </div>
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
            <div className="text-slate-500 text-xs uppercase font-bold tracking-wider mb-1">System Mode</div>
            <div className="text-2xl font-bold text-emerald-600 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse inline-block"></span>
              <span className="text-lg font-mono">sms_system</span>
            </div>
          </div>
        </section>

        {/* Tab View Container */}
        <div className="flex-1 overflow-y-auto px-8 pb-8 flex flex-col" id="workspace_container">
          <AnimatePresence mode="wait">
            {activeTab === 'terminal' && (
              <motion.div 
                key="terminal_tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch flex-1 overflow-hidden"
              >
                {/* Interactive Console column */}
                <div className="lg:col-span-7 flex flex-col rounded-xl border border-slate-200 overflow-hidden shadow-sm bg-white min-h-[440px]">
                  {/* Terminal Header Bar */}
                  <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between shrink-0">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full bg-red-500" />
                      <span className="w-3 h-3 rounded-full bg-yellow-500" />
                      <span className="w-3 h-3 rounded-full bg-green-500" />
                      <span className="text-xs font-mono text-slate-400 ml-2">sms_compiler_runtime://main.exe</span>
                    </div>
                    
                    {/* Theme Switcher */}
                    <div className="flex items-center gap-2 select-none">
                      <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider font-mono mr-1">CRT Theme:</span>
                      <button 
                        onClick={() => setTerminalTheme('phosphor')}
                        className={`w-3.5 h-3.5 rounded-full bg-emerald-500 border ${terminalTheme === 'phosphor' ? 'ring-2 ring-slate-100 ring-offset-2 ring-offset-slate-900' : 'opacity-60'}`}
                        title="Green Phosphor"
                      />
                      <button 
                        onClick={() => setTerminalTheme('amber')}
                        className={`w-3.5 h-3.5 rounded-full bg-amber-500 border ${terminalTheme === 'amber' ? 'ring-2 ring-slate-100 ring-offset-2 ring-offset-slate-900' : 'opacity-60'}`}
                        title="Amber CRT"
                      />
                      <button 
                        onClick={() => setTerminalTheme('cyberpunk')}
                        className={`w-3.5 h-3.5 rounded-full bg-fuchsia-500 border ${terminalTheme === 'cyberpunk' ? 'ring-2 ring-slate-100 ring-offset-2 ring-offset-slate-900' : 'opacity-60'}`}
                        title="Neon Cyberpunk"
                      />
                      <button 
                        onClick={() => setTerminalTheme('classic')}
                        className={`w-3.5 h-3.5 rounded-full bg-slate-500 border ${terminalTheme === 'classic' ? 'ring-2 ring-slate-100 ring-offset-2 ring-offset-slate-900' : 'opacity-60'}`}
                        title="Classic White"
                      />
                    </div>
                  </div>

                  {/* Simulated Screen Area */}
                  <div 
                    onClick={focusTerminalInput}
                    className={`flex-1 overflow-y-auto p-4 md:p-6 font-mono text-xs md:text-sm select-text whitespace-pre-wrap leading-relaxed ${themeColors.bg} ${themeColors.text} flex flex-col h-[320px]`}
                  >
                    {/* Simulated compiler boot logs */}
                    <div className="text-slate-500 text-[10px] pb-4 border-b border-slate-900 mb-4 select-none">
                      G++ COMPILER BOOT DIRECTIVE: x86_64-w64-mingw32-g++ -O3 main.cpp -o main.exe<br/>
                      CREATING STORAGE SYNC POINTER: ./students.dat (Contiguous block size: {students.length * 344} bytes)<br/>
                      LAUNCHING APPLICATION THREAD...
                    </div>

                    {/* Program outputs */}
                    <div className="flex-1 space-y-1">
                      {terminalLogs.map((log, idx) => (
                        <div key={idx} className="leading-5">{log}</div>
                      ))}
                    </div>

                    {/* Active prompt row */}
                    {terminalState !== 'exited' && (
                      <form onSubmit={handleFormSubmit} className="flex items-center gap-1.5 pt-4 border-t border-slate-900/60 mt-4 shrink-0">
                        <span className="font-semibold select-none">{terminalPrompt}</span>
                        <div className="flex-1 relative flex items-center">
                          <input
                            ref={inputRef}
                            type="text"
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            className="bg-transparent text-inherit font-mono focus:outline-none w-full caret-transparent"
                            autoFocus
                            disabled={terminalState === 'exited'}
                          />
                          {/* Custom blink caret */}
                          <span 
                            className={`absolute w-2 h-4 animate-pulse pointer-events-none ${themeColors.caret}`}
                            style={{
                              left: `${inputValue.length * 0.6}rem`,
                              top: '50%',
                              transform: 'translateY(-50%)'
                            }}
                          />
                        </div>
                      </form>
                    )}

                    {/* Keep scroll target */}
                    <div ref={terminalEndRef} />
                  </div>
                </div>

                {/* Binary Data Table / Record map column */}
                <div className="lg:col-span-5 flex flex-col min-h-[440px]" id="binary_inspector_panel">
                  <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex flex-col h-full">
                    <div className="bg-slate-50 border-b border-slate-200 px-6 py-4 flex items-center justify-between shrink-0">
                      <div>
                        <h3 className="font-bold text-slate-800 text-sm">students.dat Record Map</h3>
                        <p className="text-[11px] text-slate-500">Physical sector allocation in contiguous file streams</p>
                      </div>
                      <button 
                        onClick={clearTerminal}
                        className="text-[11px] font-bold text-blue-600 hover:underline"
                        id="clear_terminal_btn"
                      >
                        Clear Output Logs
                      </button>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto">
                      <table className="w-full text-left border-collapse">
                        <thead className="bg-slate-50 border-b border-slate-200 sticky top-0 z-10">
                          <tr>
                            <th className="px-4 py-3 text-[10px] font-bold uppercase text-slate-500 tracking-wider">Offset Range</th>
                            <th className="px-4 py-3 text-[10px] font-bold uppercase text-slate-500 tracking-wider">Roll No</th>
                            <th className="px-4 py-3 text-[10px] font-bold uppercase text-slate-500 tracking-wider">Name</th>
                            <th className="px-4 py-3 text-[10px] font-bold uppercase text-slate-500 tracking-wider text-right">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {students.map((st, i) => (
                            <tr key={st.rollNumber} className="hover:bg-blue-50/50 transition-colors">
                              <td className="px-4 py-3 font-mono text-[10px] text-slate-500">
                                0x{(i * sizeofStudent()).toString(16).toUpperCase().padStart(4, '0')} - 0x{((i + 1) * sizeofStudent() - 1).toString(16).toUpperCase().padStart(4, '0')}
                              </td>
                              <td className="px-4 py-3 font-mono text-xs font-bold text-slate-900">{st.rollNumber}</td>
                              <td className="px-4 py-3 text-xs font-semibold text-slate-900">
                                <div>{st.name}</div>
                                <div className="text-[10px] font-normal text-slate-500">{st.department} • CGPA {st.cgpa.toFixed(2)}</div>
                              </td>
                              <td className="px-4 py-3 text-right">
                                <button 
                                  onClick={() => {
                                    if (window.confirm(`Delete ${st.name} (Roll: ${st.rollNumber})?`)) {
                                      setStudents(prev => prev.filter(s => s.rollNumber !== st.rollNumber));
                                      appendLog(`System: Record with Roll Number ${st.rollNumber} removed by supervisor.`);
                                    }
                                  }}
                                  className="text-red-500 hover:underline text-xs font-bold"
                                >
                                  Delete
                                </button>
                              </td>
                            </tr>
                          ))}
                          {students.length === 0 && (
                            <tr>
                              <td colSpan={4} className="px-4 py-8 text-center text-slate-500 text-xs italic">
                                Empty file descriptor. Use the terminal, Quick-Add, or click 'Restore Defaults' in the header to populate.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* SOURCE CODE VIEWER TAB */}
            {activeTab === 'cpp' && (
              <motion.div 
                key="cpp_tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex flex-col gap-4 flex-1 overflow-hidden"
              >
                <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-col h-full min-h-[500px]">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 pb-4 mb-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-lg font-bold text-slate-900">main.cpp Source Code</h2>
                        <span className="text-xs bg-blue-50/50 text-blue-600 border border-blue-200 px-2 py-0.5 rounded-full font-mono font-medium">Standard C++11/17</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        A self-contained, fully commented C++ program that utilizes class objects, binary serialization, and standard fstream libraries.
                      </p>
                    </div>
                  </div>

                  {/* Simulated IDE / Editor viewport */}
                  <div className="flex-1 overflow-auto bg-slate-900 rounded-lg p-5 border border-slate-800 font-mono text-xs md:text-sm leading-relaxed text-slate-300">
                    <pre className="whitespace-pre">
                      {highlightCPP(cppSourceCode)}
                    </pre>
                  </div>
                </div>
              </motion.div>
            )}

            {/* EDUCATIONAL DOCUMENTATION TAB */}
            {activeTab === 'docs' && (
              <motion.div 
                key="docs_tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-8 flex-1 pb-12"
              >
                {/* Algorithm & Flowchart section */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  
                  {/* ASCII Flowchart */}
                  <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-col">
                    <div className="flex items-center gap-2.5 border-b border-slate-100 pb-4 mb-4">
                      <Layers className="w-5 h-5 text-indigo-500" />
                      <div>
                        <h3 className="text-sm font-bold text-slate-900">System Flowchart</h3>
                        <p className="text-xs text-slate-500">ASCII representation of execution routing.</p>
                      </div>
                    </div>
                    <div className="flex-1 overflow-auto bg-slate-900 p-4 rounded-lg border border-slate-800 font-mono text-[10px] md:text-xs text-cyan-300 leading-normal whitespace-pre min-h-[300px]">
                      {asciiFlowchart}
                    </div>
                  </div>

                  {/* Detailed Algorithms */}
                  <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-col">
                    <div className="flex items-center gap-2.5 border-b border-slate-100 pb-4 mb-4">
                      <Award className="w-5 h-5 text-blue-500" />
                      <div>
                        <h3 className="text-sm font-bold text-slate-900">Step-by-Step Algorithms</h3>
                        <p className="text-xs text-slate-500">Stepwise process flow breakdown of core capabilities.</p>
                      </div>
                    </div>
                    <div className="flex-1 overflow-y-auto max-h-[480px] space-y-4 pr-1">
                      {algorithmDocs.map((alg, idx) => (
                        <div key={idx} className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                          <h4 className="text-xs font-bold text-blue-600 uppercase tracking-wide mb-2">{alg.title}</h4>
                          <ol className="list-decimal list-inside space-y-1.5 text-xs text-slate-700 leading-relaxed">
                            {alg.steps.map((st, stepIdx) => (
                              <li key={stepIdx} className="pl-1">
                                <span className="text-slate-600">{st}</span>
                              </li>
                            ))}
                          </ol>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

                {/* Function & OOP Reference Dictionary */}
                <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
                  <div className="flex items-center gap-2.5 border-b border-slate-100 pb-4 mb-5">
                    <Zap className="w-5 h-5 text-yellow-500" />
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">Function & Methods Dictionary</h3>
                      <p className="text-xs text-slate-500">Description of functional boundaries within the C++ module.</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {functionExplanations.map((fn, idx) => (
                      <div key={idx} className="p-4 bg-slate-50 rounded-lg border border-slate-200 hover:border-blue-200 transition-all">
                        <div className="text-xs font-mono font-bold text-blue-600 mb-1.5">{fn.name}</div>
                        <p className="text-xs text-slate-600 leading-relaxed">{fn.description}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Technical Complexity Grid */}
                <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
                  <div className="flex items-center gap-2.5 border-b border-slate-100 pb-4 mb-5">
                    <Info className="w-5 h-5 text-blue-500" />
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">Time Complexity & Binary Layout Analysis</h3>
                      <p className="text-xs text-slate-500">Evaluating asymptotic complexity of filesystem streams.</p>
                    </div>
                  </div>
                  <div className="overflow-x-auto rounded-lg border border-slate-200">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs">
                          <th className="p-4 font-bold">C++ Function Operation</th>
                          <th className="p-4 font-bold">Asymptotic Time Complexity</th>
                          <th className="p-4 font-bold">File IO & Binary Access Explanation</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-xs">
                        {complexityData.map((data, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/40">
                            <td className="p-4 font-mono font-bold text-slate-800">{data.operation}</td>
                            <td className="p-4"><span className="px-2 py-1 bg-rose-50 text-rose-600 rounded border border-rose-100 font-mono font-bold">{data.complexity}</span></td>
                            <td className="p-4 text-slate-600 leading-relaxed">{data.description}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="mt-4 p-4 bg-slate-50 rounded-lg border border-slate-200 flex items-start gap-3">
                    <Info className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
                    <div className="text-xs text-slate-500 leading-relaxed">
                      <strong className="text-slate-800 font-semibold">Binary Storage Note:</strong> In C++, standard binary reads and writes transfer raw contiguous structures matching the compiled struct's byte footprint directly to raw memory streams. Because string length variables (`std::string`) are pointers pointing to heap addresses, storing a class holding `std::string` to disk fails. Utilizing static-size C-style arrays (e.g., `char name[50]`) preserves fixed size structures, enabling binary safety.
                    </div>
                  </div>
                </div>

                {/* Core Advantages vs Limitations */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  
                  {/* Advantages Panel */}
                  <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-col">
                    <div className="flex items-center gap-2 mb-4 text-emerald-600">
                      <ShieldCheck className="w-5 h-5" />
                      <h3 className="text-sm font-bold text-slate-900">System Advantages</h3>
                    </div>
                    <div className="space-y-4 flex-1">
                      {advantages.map((adv, idx) => (
                        <div key={idx} className="space-y-1">
                          <h4 className="text-xs font-bold text-slate-800">{adv.title}</h4>
                          <p className="text-xs text-slate-500 leading-relaxed">{adv.text}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Limitations Panel */}
                  <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-col">
                    <div className="flex items-center gap-2 mb-4 text-rose-500">
                      <Trash2 className="w-5 h-5" />
                      <h3 className="text-sm font-bold text-slate-900">Known Limitations</h3>
                    </div>
                    <div className="space-y-4 flex-1">
                      {limitations.map((lim, idx) => (
                        <div key={idx} className="space-y-1">
                          <h4 className="text-xs font-bold text-slate-800">{lim.title}</h4>
                          <p className="text-xs text-slate-500 leading-relaxed">{lim.text}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Future Enhancements Panel */}
                  <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-col">
                    <div className="flex items-center gap-2 mb-4 text-cyan-600">
                      <PlusCircle className="w-5 h-5" />
                      <h3 className="text-sm font-bold text-slate-900">Future Enhancements</h3>
                    </div>
                    <div className="space-y-4 flex-1">
                      {futureEnhancements.map((enh, idx) => (
                        <div key={idx} className="space-y-1">
                          <h4 className="text-xs font-bold text-slate-800">{enh.title}</h4>
                          <p className="text-xs text-slate-500 leading-relaxed">{enh.text}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

              </motion.div>
            )}
          </AnimatePresence>

          {/* Console Log Mockup Footer for terminal mode */}
          {activeTab === 'terminal' && (
            <footer className="h-24 bg-slate-900 mt-6 rounded-lg p-4 font-mono text-[11px] text-slate-300 border-l-4 border-blue-500 select-none shrink-0 shadow-sm" id="system_log_footer">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-emerald-500 font-bold">[SYSTEM]</span>
                <span>Success: Serialized {students.length} record(s) on disk 'students.dat'</span>
              </div>
              <div className="flex items-center gap-2 opacity-60">
                <span className="text-blue-400 font-bold">[INFO]</span>
                <span>File pointer re-indexed safely in O(1) [Append Only] time complexity.</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-500">$ ./sms_system.exe --gui-view</span>
                <span className="animate-pulse text-white font-bold">_</span>
              </div>
            </footer>
          )}
        </div>
      </main>
    </div>
  );
}

// Function to calculate exact bytes size of a student struct in C++
// Char arrays and types:
// char rollNumber[20] = 20 bytes
// char name[50] = 50 bytes
// int age = 4 bytes
// char gender[15] = 15 bytes
// char department[50] = 50 bytes
// char year[15] = 15 bytes
// char phone[20] = 20 bytes
// char email[50] = 50 bytes
// char address[100] = 100 bytes
// double cgpa = 8 bytes
// Total = 20 + 50 + 4 + 15 + 50 + 15 + 20 + 50 + 100 + 8 = 332 bytes.
// Plus compiler padding alignments make it around 336-344 bytes.
function sizeofStudent() {
  return 344;
}

// Simple highlighter function for the raw C++ code
function highlightCPP(code: string) {
  const lines = code.split('\n');
  return lines.map((line, lineIdx) => {
    // Process keywords
    let formatted = line;
    
    // Replace comments
    if (formatted.trim().startsWith('//')) {
      return (
        <div key={lineIdx} className="text-slate-500 italic">
          {formatted}
        </div>
      );
    }

    // Highlighting strategy using splits
    // Note: To keep it extremely robust and avoid JSX splitting bugs, we will just return color-styled text blocks.
    // For general keywords:
    const keywords = [
      'class', 'public', 'private', 'int', 'double', 'char', 'void', 'const', 'bool', 'return',
      'while', 'true', 'false', 'if', 'else', 'switch', 'case', 'break', 'default', 'do',
      'using', 'namespace', 'include', 'struct', 'sizeof', 'reinterpret_cast'
    ];

    // Simple word splitting logic
    const tokens = formatted.split(/(\s+|\(|\)|\{|\}|\[|\]|;|,|<|>|&|\||\+|-|=|\*|\\|\"|\'|\!)/);
    
    const renderedTokens = tokens.map((token, tokIdx) => {
      if (keywords.includes(token)) {
        return <span key={tokIdx} className="text-rose-400 font-bold">{token}</span>;
      }
      if (token.startsWith('"') || token.endsWith('"') || token.startsWith("'")) {
        return <span key={tokIdx} className="text-emerald-400">{token}</span>;
      }
      if (/^\d+(\.\d+)?$/.test(token)) {
        return <span key={tokIdx} className="text-amber-400">{token}</span>;
      }
      if (['cout', 'cin', 'endl', 'ifstream', 'ofstream', 'fstream', 'string'].includes(token)) {
        return <span key={tokIdx} className="text-sky-400 font-medium">{token}</span>;
      }
      if (['Student', 'strcpy', 'strcpy', 'strncpy', 'strcmp', 'strlen', 'getline', 'setw', 'setprecision', 'fixed', 'left', 'right', 'main'].includes(token)) {
        return <span key={tokIdx} className="text-indigo-300 font-semibold">{token}</span>;
      }
      return <span key={tokIdx}>{token}</span>;
    });

    return (
      <div key={lineIdx} className="min-h-[1rem]">
        <span className="text-slate-600 inline-block w-8 select-none text-[10px] mr-2 text-right">{lineIdx + 1}</span>
        {renderedTokens}
      </div>
    );
  });
}
